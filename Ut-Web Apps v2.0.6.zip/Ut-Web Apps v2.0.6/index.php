<?php session_start(); ?>
<!DOCTYPE html>
<html>
<!--[if gt IE 9]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<title>Ut-Web Apps</title>
<link rel="icon" type="image/png" href="Images/Logo-34441_ico.png"/>
<meta charset="utf-8" />
<!-- Setting the viewport and X-UA to make your website look good on all devices: -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">


<!-- Define a description of your web page: -->
<meta name="description" content="Use our online free SEO Tools and many useful Websites to create or develop something as you want and make your work easier.">

<!-- Define keywords for search engines: -->
  <meta name="keywords" content=" ISO 
Tools and websites.
">


<!-- Define the author of a page or websites: -->
  <meta name="author" content="Tarun Raghav">

<meta name="google-site-verification" content="VRwCnsnIvIhRFX-HgqkCWujbnLLlrmOrkQEjdGWow8w" />
<script data-ad-client="ca-pub-9637256639795545" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <link rel="stylesheet" type="text/css" href="Offline-Online-Status/offline-theme-dark.css">
  <link rel="stylesheet" href="Offline-Online-Status/offline-language-english.min.css" />
  <script src="Offline-Online-Status/offline.min.js"></script>

<!-- remove-000webhost-Banner -->
<script src="Index_Resources/includes/remove-000webhost-Banner.js"></script>

<style>
<!-- lNDEX PAGE/CONTENTS - STYLE --> 
<?php include "Index_Resources/style.css"; ?>
</style>

<style>
body {
  background-image: url('Images/jurassic-coast-1089035_1920.jpg');
}
</style>

</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- NAVIGATION BAR -->
<?php include "Index_Resources/includes/navigation-bar.php" ?>

<div class="div">
<style>
.nav-bar-2 {
  color: black;
  margin-top: 20px;
  top: 40px;
  left: 50px;
  width:90%;
  }

.nav-bar-2:hover {
  color: #35FFFF;
  border: 1px solid #35FFFF;
}

@media screen and (max-width: 600px) {
.nav-bar-2 {
  color: black;
  margin-top: 20px;
  left: 50px;
  width:90%;
  }

.nav-bar-2:hover {
  color: #35FFFF;
}
}
</style>
<br/>
<center>

<nav class="nav-bar-2" >
<!-- LOGIN -->
<?php include "Index_Resources/includes/login.php"; ?>

<!-- Register -->
<?php include "Index_Resources/includes/register.php"; ?>

</nav>
</center>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- ///////////////{ PAGE LOADER }/////////////// -->
  <!DOCTYPE html>
  <html>
  <head>
  <title>Ut-Apps</title>
  <link rel="icon" type="image/png" href="Logo-34441_ico.png"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
  <style>
  .Pageloader{
  position: fixed;
  z-index: 9999;
  background-color: skyblue;
  width:90%;
  height: 100%;
  top:30%;
  left:0%;
  right:10%
  }

  .loader-img {
  position: fixed;
  width: 40%;
  top:5%;
  left:30%;
  margin-top:40px;
  padding: 0px;
  }

@media screen and (max-width: 600px) {
  .Pageloader{
  position: fixed;
  z-index: 9999;
  background-color: skyblue;
  top:60%;
  left:0%;
  right: 40%;
}

.loader-img {
position: fixed;
width: 80%;
top:10%;
left:10%;
margin-top:40px;
padding: 0px;
}

}
  </style>
  <body>
<center>
  <div class="Pageloader" id="divLoading" style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: ; background-image: url('Images/jurassic-coast-1089035_1920.jpg'); z-index: 30001; opacity: 1.1;">
 <br/>
  <h1 style="position: absolute; color: black; text-align: center;">

<!-- LOADER IMAGE- GIF -->
<img class="loader-img"
  <source src="Images/Pageloader.gif" >
<br/>
  <a href="Unfunny-truth_OS.html" style="background: lightblue;border: 1px solid black;"></a>
  </h1>
  <!-- Ut [Button-on Loader]-->
  <a href="Unfunny-truth_OS.html" style="
  color: black;
  border: 1px solid #35FFFF;
  background-color: skyblue;
  margin-top:;
  top: 25px;
  left: 19px;">Ut-Web Apps</a>
  </div>
  <h1></h1>
</center>
  <script>
  window.onload = function() 
  {
  //display loader on page load 
  $('.Pageloader').fadeOut();
  }
  </script>
</body>
</html>

<!-- ///////////////////////////// -->
<div class="div">
<style>
.Ut-osbutton {
  color: black;
  border: 1px solid #35FFFF;
  background-color: skyblue;
  
  }
.Ut-osbutton:hover {
  color: #35FFFF;
  background-color: #365667;
  border: 2px solid red;
  
}
</style>

  <style>
  /* <!--Page Content's style --> */
  </style>
  </head>
  <body>
<center>
  <div class="content">
  
  <!-- Show All Contents from INDEXER (using PHP include/Iframe)-->
<!--
  <?php include "" ?>
-->

<style>

.my-iframe {
  height:calc(100vh - 4px);
  width:calc(75vw - 3px);
  box-sizing: border-box;
}

@media screen and (max-width: 600px) {
.my-iframe {
  height:calc(100vh - 4px);
  width:calc(75vw - 23px);
  box-sizing: border-box;
}
}
</style>

<iframe class="my-iframe" src="Index_Resources/indexer/INDEXER.php" height="100%" width="100%" frameborder="0">
</iframe>

  </div>
  <br/>
</center>
  </body>
  </html>
  <!-- Website logo/image [Bottom] -->
  <!DOCTYPE html>
  <html>
  <body>
  <a href="about-us-page.php">
  <img alt="Contact us" src="Images/Logo-34441_ico.png"
  width="auto" height="auto">
  </a>
  </body>
  </body>
  </html>
</div>

<!--Check-Online-or-Offline-Status(Script)--->
<script type="text/javascript">
Offline.options = {
  // to check the connection status immediatly on page load.
  checkOnLoad: true,

  // to monitor AJAX requests to check connection.
  interceptRequests: true,

  // to automatically retest periodically when the connection is down (set to false to disable).
  reconnect: {
    // delay time in seconds to wait before rechecking.
    initialDelay: 3,

    // wait time in seconds between retries.
    delay: 10
  },

  // to store and attempt to remake requests which failed while the connection was down.
  requests: true
};
</script>


<!-- FOOTER -->
<?php include "Index_Resources/includes/footer.php"; ?>

</body>
</html>