	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			<li class="ts-label">Menu</li>

                        <li><a href="home.php"><i class="fa fa-home"></i> &nbsp;Home</a>
			</li>
                        <li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;My Profile</a>
			</li>
			<li><a href="feedback.php"><i class="fa fa-envelope"></i> &nbsp;Feedback</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification<sup style="color:red">*</sup></a>
			</li>
			<li><a href="messages.php"><i class="fa fa-envelope"></i> &nbsp;Messages</a>
			</li>
                       <li><a href="#" onclick="requestDesktopSite()"><i class="fa fa-desktop"></i> &nbsp;Desktop site</a>

<script>
function requestDesktopSite(){
 if(document.getElementsByTagName('meta')['viewport'].content=='width= 1440px;'){
  document.getElementsByTagName('meta')['viewport'].content='width= 400px;';
 }else{
  document.getElementsByTagName('meta')['viewport'].content='width= 1440px;';
 }
}
</script>
			</li>
                        <li><a href="change-password.php"><i class="fa fa-key"></i> &nbsp;Change Password</a>
			</li>
                        <li><a href="logout.php"><i class="fa fa-sign-out"></i> &nbsp;logout</a>
			</li>
			</ul>
<br/>
<center>
<!-- //////////////© COPYRIGHT NOTICE ////////////////// -->
<!-- © -->
<font size="-1">
  <a style="background-color: #364655; border-radius: 5px;
  color: #35FFFF;" href="../../../about-us-page.php"> © <script>document.write(new Date().getFullYear())</script> Tarun Raghav •</a>
</font>
</center>
	</nav>

		