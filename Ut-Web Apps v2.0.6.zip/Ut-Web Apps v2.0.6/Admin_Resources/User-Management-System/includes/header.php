 <!-- Offline Online Status -->
<link rel="stylesheet" type="text/css" href="../../Offline-Online-Status/offline-theme-dark.css">
  <link rel="stylesheet" href="../../Offline-Online-Status/offline-language-english.min.css" />
  <script src="../../Offline-Online-Status/offline.min.js"></script>

<style>
.fa {
color: #35FFFF;
background: #333333;
border-radius: 2px;
}
</style>

<?php
// GET User Details
		$email = $_SESSION['alogin'];
		$sql = "SELECT * from users where email = (:email);";
		$query = $dbh -> prepare($sql);
		$query-> bindParam(':email', $email, PDO::PARAM_STR);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>

<!-- Background Image -->
<style>
body {
  background-image: url('../../Images/jurassic-coast-1089035_1920.jpg');
}

 h2, h3 {
  border: 1px solid #575757;
  border-radius:4px;
  background: #353636;
  color: white;
  height:30px
  
}
</style>

<div class="brand clearfix">
<h4 class="pull-left text-white text-uppercase" style="margin:20px 0px 0px 20px">
<i class="fa fa-user"></i>
&nbsp; 

<!-- Show Name of user --><?php echo htmlentities($result->name);?>

<!-- Show Email of user 
<?php echo htmlentities($_SESSION['alogin']);?>
-->

</h4>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="images/<?php echo htmlentities($result->image);?>" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
                                       <li><a href="#" onclick="requestDesktopSite()"><i class="fa fa-mobile fa-lg"></i> &nbsp;Mobile site</a>

<script>
function requestDesktopSite(){
 if(document.getElementsByTagName('meta')['viewport'].content=='width= 1440px;'){
  document.getElementsByTagName('meta')['viewport'].content='width= 400px;';
 }else{
  document.getElementsByTagName('meta')['viewport'].content='width= 1440px;';
 }
}
</script>
			</li>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
