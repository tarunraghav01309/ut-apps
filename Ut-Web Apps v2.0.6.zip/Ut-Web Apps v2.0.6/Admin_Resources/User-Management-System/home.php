<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{   
?>

<!Doctype html>
<html lang="en" class="no-js">
<head>

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Ut-Apps | Home</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<script type= "text/javascript" src="../vendor/countries.js"></script>
	<style>
	.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>

</head>

<body>
<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
<!-- PAGE TITLE -->
<!--
<h3 class="page-title" style="height: 2px;">Home</h3>
<br/>
-->
	
         <div class="row">
       <div class="col-md-12">
								<div class="panel panel-default">

<!--
									<div class="panel-heading">Ut-Apps | Home
</div>
-->

<!--//////////// Heading + Button ///////////-->
<div class="panel-heading">
<style>
.ut-os-button {
  color: black;
  border: 2px solid white;
  background-color: ;
  position: relative;
  margin-top: 20px;
  top: 2px;
  left: 0px;
  }

@media screen and (max-width: 600px) {
.ut-os-button {
  color: black;
  border: 2px solid white;
  background-color: ;
  position: relative;
  margin-top: 20px;
  top: 2px;
  left: 0px;
  }
}

.ut-os-button:hover {
  color: #35FFFF;
  background-color: #365667;
  border: 2px solid red;
}

}
</style>
<a class="ut-os-button" href="../../Unfunny-truth_OS.html">Ut-Apps | Home</a>
</div>
<!--/////////////////////////////////-->
									   <div class="panel-body">
<!--/////////////// HOME CONTENTS ////////////////-->

<style>
.my-iframe {
  height:calc(100vh - 4px);
  width:calc(94vw - 3px);
  box-sizing: border-box;
}

@media screen and (max-width: 600px) {
.my-iframe {
  height:calc(100vh - 4px);
  width:calc(90vw - 23px);
  box-sizing: border-box;
}
}
</style>
<?php
 $DomainURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; 
 ?>


<iframe class="my-iframe" src="<?php echo $DomainURL; ?>/Index_Resources/indexer/INDEXER.php" height="100%" width="100%" frameborder="0">
</iframe>

<!--//////////////////////////////////////////////////////////-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					});
	</script>
</body>
</html>
<?php } ?>