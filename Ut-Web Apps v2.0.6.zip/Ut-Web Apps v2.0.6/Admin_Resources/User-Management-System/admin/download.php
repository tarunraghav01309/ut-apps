<?php 
session_start();
error_reporting(0);
session_regenerate_id(true);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0)
{	
header("Location: index.php"); //
}
else{?>

<script>

(function(exports) {
    function urlsToAbsolute(nodeList) {
        if (!nodeList.length) {
            return [];
        }
        var attrName = 'href';
        if (nodeList[0].__proto__ === HTMLImageElement.prototype || nodeList[0].__proto__ === HTMLScriptElement.prototype) {
            attrName = 'src';
        }
        nodeList = [].map.call(nodeList, function(el, i) {
            var attr = el.getAttribute(attrName);
            if (!attr) {
                return;
            }
            var absURL = /^(https?|data):/i.test(attr);
            if (absURL) {
                return el;
            } else {
                return el;
            }
        });
        return nodeList;
    }

    function screenshotPage() {
        var wrapper = document.getElementById('wrapper');
        html2canvas(wrapper, {
            onrendered: function(canvas) {
                canvas.toBlob(function(blob) {
                    saveAs(blob, 'users_list.png');
                });
            }
        });
    }

    function addOnPageLoad_() {
        window.addEventListener('DOMContentLoaded', function(e) {
            var scrollX = document.documentElement.dataset.scrollX || 0;
            var scrollY = document.documentElement.dataset.scrollY || 0;
            window.scrollTo(scrollX, scrollY);
        });
    }

    function generate() {
        screenshotPage();
    }
    exports.screenshotPage = screenshotPage;
    exports.generate = generate;
})(window);
</script>




<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<title>Users List</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.3/FileSaver.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>

<style>
@import url(https://fonts.googleapis.com/css?family=Merriweather);
$red: #e74c3c;
*,
*:before,
*:after {
    @include box-sizing(border-box);
}

html,
body {
   /* background: #f1f1f1; */
    font-family: 'Merriweather', sans-serif;
    /* padding: 1em; */
}

h1 {
  /*  text-align: center; */
    color: #a8a8a8;
    @include text-shadow(1px 1px 0 rgba(white, 1));
}


#photo{
/* border: 1px solid silver; */
padding: 4px;
width: 100px;

}
</style>
<style>  
  table {  
    font-family: arial, sans-serif;  
    border-collapse: collapse; 
    margin: 0px auto;
   border: 4px solid green;
   align-content: left;
   width: 50%;
   height: auto;
  }
  #htmlContent{
    text-align: center;
  }  
  td, th{  
    border: 2px solid green;  
    text-align: left;  
    
  }  
  button {  
    border: 1px solid black;   
  } 
  tr:nth-child(even) {  
    background-color: #dddddd;  
  }  
</style>  
</head>

<body>
<div id="wrapper">




<div id="photo">
<u><h3>Users List</h3></u>

<table border="1">
<thead>
<tr>
<th>#</th>
<th>Name</th>
<th>Email</th>
<th>Gender</th>
<th>Phone</th>
<th>Designation</th>
</tr>
</thead>

<?php 
$filename="Users list";
$sql = "SELECT * from users";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				

echo '  
<tr>  
<td>'.$cnt.'</td> 
<td>'.$Name= $result->name.'</td> 
<td>'.$Email= $result->email.'</td> 
<td>'.$Gender= $result->gender.'</td> 
<td>'.$Phone= $result->mobile.'</td> 
<td>'.$Designation= $result->designation.'</td> 					
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$cnt++;
}
}
?>
</table>


<?php } ?>


</div>
<br/>
</div>


<a class="btn btn-success" href="javascript:void(0);" onclick="generate();">Download as image/png</a>


</body>
</html>

