<?php
//Define Web Apps Folder LOCATION to count Apps 
$AppsDir = "../../../Index_Resources/indexer/";
$appsCount = 0;
$dh = opendir($AppsDir);
while (($file = readdir($dh)) !== false) {
    if ($file != "." && $file != ".." && is_dir($AppsDir . DIRECTORY_SEPARATOR . $file)) {
        $appsCount++;
    }
}
closedir($dh);

?>

<!--
Apps Dir = <?php echo("$AppsDir"); ?>
<br/>

Apps = <?php echo("$appsCount"); ?>
<br/>
-->