	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
	                <li class="ts-label">Menu</li>
		        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Admin Profile</a>
			</li>
			<li><a href="userlist.php"><i class="fa fa-users"></i> Users List</a>
			</li>
                      <li><a href="deleteduser.php"><i class="fa fa-user-times"></i> &nbsp;Deleted Users</a>
			</li>
			<li><a href="download.php"><i class="fa fa-download"></i> &nbsp;Download Users-List</a>
                      <li><a href="feedback.php"><i class="fa fa-envelope"></i> &nbsp;Feedback</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification <sup style="color:red">*</sup></a>
			</li>
                        <li><a href="../../../tiny-file-manager/index.php"><i class="fa fa-folder-open"></i>Tiny-File Manager</a></li>
                        <li><a href="../../../tiny-file-manager/fileshare/admin.php"><i class="fa fa-paper-plane"></i>File-Share</a></li>

<li><a href="../../../Index_Resources/indexer/.Zip-Files-Installer.php"><i class="fa fa-plus"></i>Zip Files-Installer</a></li>

                         <li><a href="../../../Index_Resources/indexer/GD-Video Stream/admin.php"><i class="fa fa-caret-square-o-right" style="font-size:;color:;"></i>GD-Video Stream</a></li>

<li><a href="Adminer/adminer-4.8.1.php"><i class="fa fa-database"></i>Hydra Adminer</a></li>

                        <li><a href="#" onclick="requestDesktopSite()"><i class="fa fa-desktop"></i> &nbsp;Desktop site</a>

<script>
function requestDesktopSite(){
 if(document.getElementsByTagName('meta')['viewport'].content=='width= 1440px;'){
  document.getElementsByTagName('meta')['viewport'].content='width= 400px;';
 }else{
  document.getElementsByTagName('meta')['viewport'].content='width= 1440px;';
 }
}
</script>
			</li>
<li><a href="change-password.php"><i class="fa fa-key"></i> &nbsp;Change Password</a>
			</li>
<li><a href="logout.php"><i class="fa fa-sign-out"></i> &nbsp;logout</a>
			</li>

			</ul>
<br/>
<center>
<!-- //////////////© COPYRIGHT NOTICE ////////////////// -->
<!-- © -->
<font size="-1">
  <a style="background-color: #364655; border-radius: 5px;
  color: #35FFFF;" href="../../../about-us-page.php"> © <script>document.write(new Date().getFullYear())</script> Tarun Raghav •</a>
</font>
</center>
	</nav>
		