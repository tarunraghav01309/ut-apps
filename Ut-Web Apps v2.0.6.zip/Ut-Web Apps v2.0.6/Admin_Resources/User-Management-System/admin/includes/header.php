<style>
.fa {
color: #35FFFF;
background: #333333;
border-radius: 2px;
}
</style>

<div class="brand clearfix">
<h4 class="pull-left text-white" style="margin:20px 0px 0px 20px"><i class="fa fa-rocket"></i>&nbsp; Admin Panel</h4>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
                                        <li><a href="#" onclick="requestDesktopSite()"><i class="fa fa-mobile fa-lg"></i> &nbsp;Mobile site</a>

<script>
function requestDesktopSite(){
 if(document.getElementsByTagName('meta')['viewport'].content=='width= 1440px;'){
  document.getElementsByTagName('meta')['viewport'].content='width= 400px;';
 }else{
  document.getElementsByTagName('meta')['viewport'].content='width= 1440px;';
 }
}
</script>
			</li>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
