<?php
$units = explode(' ', 'B KB MB GB TB PB');

//Define Total Disk Space Below in mebibytes or gibibytes
$SIZE_LIMIT = 314572800; // 300MB
$disk_used = foldersize("./");

$disk_remaining = $SIZE_LIMIT - $disk_used;

//echo("<html><body>");
$DiskSpaceUsed = ('' . format_size($disk_used) . '');
$DiskSpaceLeft = ('' . format_size($disk_remaining) . '');
// echo("</body></html>");


function foldersize($path) {
$total_size = 0;
$files = scandir($path);
$cleanPath = rtrim($path, '/'). '/';

foreach($files as $t) {
if ($t<>"." && $t<>"..") {
$currentFile = $cleanPath . $t;
if (is_dir($currentFile)) {
$size = foldersize($currentFile);
$total_size += $size;
}
else {
$size = filesize($currentFile);
$total_size += $size;
}
}   
}

return $total_size;
}


function format_size($size) {
global $units;

$mod = 1024;

for ($i = 0; $size > $mod; $i++) {
$size /= $mod;
}

$endIndex = strpos($size, ".")+3;

return substr( $size, 0, $endIndex).' '.$units[$i];
}

?>


<!--
Diskspace used: = <?php echo("$DiskSpaceUsed") ;?>
<br>

<?php
echo(round($DiskSpaceUsed) . "");
?>
 <br/>


Diskspace left: = <?php echo("$DiskSpaceLeft");?>
<br/>

<?php
echo(round($DiskSpaceLeft) . "");
?>
 <br/>

<hr/>
-->

<?php
# Size in Bytes
$size = $SIZE_LIMIT;
# Call this function to convert bytes to KB/MB/GB/TB
$TotalSize = convertToReadableSize($size);
# Output => 14.2 MB

function convertToReadableSize($size){
  $base = log($size) / log(1024);
  $suffix = array("", "KB", "MB", "GB", "TB");
  $f_base = floor($base);
  return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
}
?>

<!--
<?php echo("$TotalSize"); ?>
<br/>

<?php
echo(round($TotalSize) . "");
?>
 <br/>
-->

<?php
// Total Count All Values in array
$a = array(2, 4, 6, 8);
$TotalValue ="" . array_sum($a) . "\n";
?>

<!--
Total Value = <?php echo("$TotalValue"); ?>
-->
