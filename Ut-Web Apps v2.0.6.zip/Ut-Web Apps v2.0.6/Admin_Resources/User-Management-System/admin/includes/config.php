<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','id17218874_utapps_admin');
define('DB_PASS','Hpsc@123456789');
define('DB_NAME','id17218874_login_system');
// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>