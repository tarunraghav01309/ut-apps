Usage:
------------
1] Download and unzip the file-uploader-script.zip file.
2] Five files named "index.php, upload.php, jquery.js, readme.txt and ajaxloader.gif" with an empty upload folder will be obtained.
3] The files which you upload will be downloaded inside "Upload" folder.
4] Now run the index.php in your browser to view the functionality of the script.


Index.php:
--------------------
1] Upload.php file helps to upload the file from the given URL.
2] It reads and writes the file name in the given URL.


upload.php:
-----------
1] Upload.php helps to upload the file from the given remote URL.

2] It reads and writes the file name in the given URL.


How to embed the script in to your webpage?
---------------------------------------------------------------
1] Open the index.php file.
2] The script code is available inside the <body> of the Index.php file. Copy the code within the <body></body> tag and paste it in your web page where you want to show the script.
3] To include the uploadfile() function, just copy the code inside the <script type="text/javascript"></script> and paste it in the required portion of your webpage.

Script provided by:
*******************
This script is developed and owned by Hscripts.com
This is given under The GNU General Public License (GPL).

Downloads:
-----------
Please visit our site

http://www.hscripts.com/scripts/php/file-uploader-script.php to download the script

For further enquiries and support, mail us to support@hscripts.com

Thanks & regards,
Hscripts Team
Visit us at http://www.hscripts.com

