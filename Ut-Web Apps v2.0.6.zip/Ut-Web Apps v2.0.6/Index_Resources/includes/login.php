<?php 
//Get Domain URL
include("GetDomainURL.php");

// DB Configuration
include("DB-Config-Login.php");
?>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<style>
/*
body{
height: 100vh;
text-align: center;
}
*/

/*Trigger Button*/
.login-trigger {
font-weight: bold;
color: #fff;
background: linear-gradient(to bottom right, #B05574, #F87E7B);
border-radius: 3px;
padding: 5px 5px;
/*
position: relative; 
top: 50%;
*/
}

.login-button-input {
color: white;
border: none;
margin-left: 4px;
height: ;
}

/*Modal*/
h4 {
font-weight: bold;
color: #fff;
}

.close {
color: #fff;
transform: scale(1.2)
}
.modal-content {
font-weight: bold;
background: linear-gradient(to bottom right,#F87E7B,#B05574);
}
.form-control {
margin: 1em 0;
}
.form-control:hover, .form-control:focus {
box-shadow: none;  
border-color: #fff;
}
.username, .password {
border: none;
border-radius: 0;
box-shadow: none;
border-bottom: 2px solid #eee;
padding-left: 0;
font-weight: normal;
background: transparent;  
}
.form-control::-webkit-input-placeholder {
color: #eee;  
}
.form-control:focus::-webkit-input-placeholder {
font-weight: bold;
color: #fff;
}
.login {
padding: 6px 20px;
border-radius: 20px;
background: none;
border: 2px solid #FAB87F;
color: #FAB87F;
font-weight: bold;
transition: all .5s;
margin-top: 1em;
}
.login:active{
background: #FAB87F;
color: #fff;
}
.login:hover {
background: #FAB87F;
color: #fff;
}
</style>

<!--Trigger-->
<input type="button" class="login-trigger login-button-input" data-target="#login" data-toggle="modal" value="Login"/>

<div id="login" class="modal fade" role="dialog">
<div class="modal-dialog">

<div class="modal-content">
<div class="modal-body">
<button data-dismiss="modal" class="close">&times;</button>
<h4>Login</h4>
<form action="#" method="post">

<input type="email" name="username" class="username form-control" placeholder="Email" required>

<input type="password" name="password" class="password form-control" placeholder="password"/>
<input class="btn login" name="login" type="submit" value="Login" />

</form>
</div>
</div>
</div>  
</div>