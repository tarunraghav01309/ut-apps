<?php 
//Get Domain URL
include("GetDomainURL.php");

// Define Registration Form URL
$GetDomainURL = "$GetDomainURL";
$RegistrationFormURL = "/Admin_Resources/User-Management-System/register.php";

$RegistrationFormURL = "$GetDomainURL$RegistrationFormURL";

?>

<!--
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
-->

<style>
/*
​body{
  height: 100vh;
  text-align: center;
}
*/

  /*Trigger Button*/
.login-trigger {
  font-weight: bold;
  color: #fff;
  background: linear-gradient(to bottom right, #B05574, #F87E7B);
  border-radius: 3px;
  padding: 5px 5px;
/*
  position: relative; 
  top: 50%;
*/
}

.login-button-input {
  color: white;
  border: none;
  margin-left: 4px;
  height: ;
}

/*Modal*/
h4, h6 {
  font-weight: bold;
  color: #fff;
}

.close {
  color: #fff;
  transform: scale(1.2)
}
.modal-content {
  font-weight: bold;
  background: linear-gradient(to bottom right,#F87E7B,#B05574);
}
.form-control {
  margin: 1em 0;
}
.form-control:hover, .form-control:focus {
  box-shadow: none;  
  border-color: #fff;
}

.name, .email, .password, .designation, .mobileno, .gender, .image {
border: none;
border-radius: 0;
box-shadow: none;
border-bottom: 2px solid #eee;
padding-left: 0;
font-weight: normal;
background: transparent;  
color: black;
}
.form-control::-webkit-input-placeholder {
  color: #eee;  
}
.form-control:focus::-webkit-input-placeholder {
  font-weight: bold;
  color: #fff;
}
.register {
  padding: 6px 20px;
  border-radius: 20px;
  background: none;
  border: 2px solid #FAB87F;
  color: #FAB87F;
  font-weight: bold;
  transition: all .5s;
  margin-top: 1em;
}
.register:active{
  background: #FAB87F;
  color: #fff;
}
.register:hover {
  background: #FAB87F;
  color: #fff;
}
</style>
 <style>
 .circle {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  border:none;
  border: 2px solid #FAB87F;
  line-height:50px;
  text-align:center;
  font-size: 30px;
  color: white;
 }
 </style>
​<!--Trigger-->
<input onclick="sample()" id= "gameStart" type="button" class="login-trigger login-button-input" data-target="#register" data-toggle="modal" value="Register"/>

<div id="register" class="modal fade" role="dialog">
  <div class="modal-dialog">
    
    <div class="modal-content">
      <div class="modal-body">
        <button data-dismiss="modal" class="close">&times;</button>
        <h4>Register Now! as new user.</h4>
<br>

<div id="countdown" class="circle"></div>

<button class="btn register" name="submit" type="submit" value="Register" onclick="javascript:location.href='<?php echo("$RegistrationFormURL"); ?>'" type="button">Register
  </button>

 <script>
 var timeleft = 10;
 function sample() {
 var downloadTimer = setInterval(function 
 function1(){ 
 document.getElementById("countdown").innerHTML = timeleft + "&nbsp"+"<!-- seconds remaining -->";
 
 timeleft -= 1;
 if(timeleft <= 0){
 clearInterval(downloadTimer);
 
 document.getElementById("countdown").innerHTML = "<style>.circle {width:150px; font-size:20px; border:none; border-radius:0px;; color:green; color:white;}</style>Loading...";
 window.location = '<?php echo("$RegistrationFormURL"); ?>';
}
}, 1000);

console.log(countdown)
}
 </script>


<br/><br/><br/>

<h6>* Free Use Latest Version of this Website Forever.</h6>
<h6>* latest Ut-Web Apps with regular updates.</h6>
<h6>* Public Upload Enabled.</h6>
<h6>* New Menu with more advance options like</h6>
<h6>User Profile, Messages, Feedback, Reset Password, Desktop Mode.etc</h6>

      </div>
    </div>
  </div>  
</div>
