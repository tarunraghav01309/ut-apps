<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
/* <!-- Navigation Bar style --> */

* {
  margin: ;
  padding: ;
  box-sizing: border-box;
  }
  
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}


.topnav {
  overflow: hidden;
  background-color: #333;
   position: fixed;
    width: 80%;
    left: 38px;
    top: -20px;
}


@media screen and (max-width: 600px) {
.topnav {
  overflow: hidden;
  background-color: #333;
   position: fixed;
    width: 80%;
    left: 15px;
    top: -20px;
}
}


.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 14px;
  text-decoration: none;
  font-size: 14px;
}

.topnav a:hover {
  background-color: #365667;
  color: #35FFFF;
}

.topnav a.active {
  background-color: #364655;
  color: #35FFFF;
}

.topnav .icon {
  display: none;
  background-color: black;
  color: #35FFFF;
  height: 47px;
}


@media screen and (max-width: 1800px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}


@media screen and (max-width: 1800px) {
    
  .topnav.responsive {position: relative;}

  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }


  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  
}


 div {
 margin: 6%;
 padding: 0%;
 box-sizing: border-box;
 }
</style>

<div class="topnav" id="myTopnav">
  
  <a href="./" class="active">Home</a>
  <a href="Index_Resources/indexer/Ut-Blogs/">Ut-Blogs</a>
  <a href="https://drive.google.com/drive/u/0/mobile/folders/1nKReVyMmciIaS0mitMcP40BAYkk_5Rjq">Drive Music Videos</a>
  <a href="https://drive.google.com/folderview?id=1z81vOehGdFSSQvjkQvpFg4x6oCCB7fNS">Drive Hindi Movies</a>

  <a href="https://we45jmsso23hmfbv8wugvw-on.drv.tw/Red%20Music%20Player/Red_Music_player-v1.4.zip%20(Unzipped%20Files)/Red_Music_player-v1.4.html">Red Music Player v1.4</a>
  <a href="https://www.socialcreator.com/driveuploader">Drive Uploader v6</a>
  
  
  
  <a href="tiny-file-manager/fileshare/index.php">File Share</a>
  <a href="tiny-file-manager/index.php">Tiny File Manager</a>
  <a href="sitemap.xml" style="display: none;">sitemap</a>
  <a href="about-us-page.php" style="
  background-color: #333333;
  border: 1px solid #35FFFF;">About us</a>
  
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
  </div>

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>