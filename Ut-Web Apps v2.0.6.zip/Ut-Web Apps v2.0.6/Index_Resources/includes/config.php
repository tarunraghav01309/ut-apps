<?php
    $host  = "localhost";
     $user  = "id17218874_utapps_admin";
     $password   = "Hpsc@123456789";
     $database  = "id17218874_login_system"; 
?>
