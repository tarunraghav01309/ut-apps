<!-- © -->
<font size="-1">
  <a style="background-color: #364655; border-radius: 5px;
  color: #35FFFF;" href="about-us-page.php"> © <script>document.write(new Date().getFullYear())</script> Tarun Raghav •</a>
</font>