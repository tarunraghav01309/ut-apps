<?php
// Configuration for All Files-

// Hide All PHP Errors
error_reporting(0);

// Define Website Title
$title = "WR-Text Pad";

// Define Website Logo URL
$logoURL = "images/WR-Text Pad.png";


// Get File Name [by Input Form]
$FileName = $_GET['FileName'];

// Get Contents or Texts [by Input Form]
$TextContent = $_GET['textContent'];

// Define File Name to Write in File [Optional]
//$FileName = "File.txt";

// Define Contents or Texts to Write in File [Optional]
//$TextContent = "Example Text.";

// fwrite.php
// Open a file in which mode - r or w
// r = read mode
// w = write mode
$ModeW = "w";


// fread.php
// Open a file in which mode - r or w
// r = read mode
// w = write mode
$ModeR = "r";

// Number of bytes/text to read from File [optional] [disabled]
// $NumbersOfText = "100000";

?>