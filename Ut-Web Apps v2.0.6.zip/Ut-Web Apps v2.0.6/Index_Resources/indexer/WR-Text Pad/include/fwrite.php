<?php
// Include Configuration File
include("config.php");
?>

<?php 
// Define File Name & Mode
$FileName = "$FileName";
$ModeW = "$ModeW";

// Open a file in write mode 
$data = fopen("$FileName", "$ModeW"); 

// writing content to a file using fwrite() function 
$TextCount = fwrite($data, "$TextContent"); 

// closing the file 
fclose($data); 
?> 

<!-- 
<title><?php echo $title; ?></title>

<link rel="icon" type="image/png" href="<?php echo $logoURL; ?>"/>

File Name = 
<?php echo("$FileName"); ?>
<br/>

Total Text = 
<?php echo("$TextCount"); ?>
<br/>

-->