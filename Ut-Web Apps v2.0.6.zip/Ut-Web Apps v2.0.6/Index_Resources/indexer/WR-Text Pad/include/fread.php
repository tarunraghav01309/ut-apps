<?php
// Include Configuration File
include("config.php");
?>

<?php 
// Define File Name & Mode
$FileName = "$FileName";
$ModeR = "$ModeR";
$NumbersOfText = "$NumbersOfText";

// Open a file in read mode 
$data = fopen("$FileName", "$ModeR"); 

// reading contents from a file using fread() function 
// Read Half File Content [Specified in Config.php]
//$ReadFile = fread($data, "$NumbersOfText"); 
//or
//Read Full File Content
$ReadFile = fread($data, filesize($FileName));

// closing the file 
fclose($data); 
?> 

<!--
<title><?php echo $title; ?></title>

<link rel="icon" type="image/png" href="<?php echo $logoURL; ?>"/>

File Name = 
<?php echo("$FileName"); ?>
<br/>

File Read = 
<?php echo("$ReadFile"); ?>
<br/>
-->