<?php
// Include f-write.php File
include("include/fwrite.php");

// Include f-read.php File
include("include/fread.php");

?>

<!-- 
File Name = 
<?php echo("$FileName"); ?>
<br/>

Total Text = 
<?php echo("$TextCount"); ?>
<br/>

-->

<!Doctype HTML>
<html>
<title><?php echo $title; ?></title>
<link rel="icon" type="image/png" href="<?php echo $logoURL; ?>"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<head>
<style>

body{
color: orange;
}

/*Trigger Button*/
.login-trigger {
font-weight: bold;
color: #fff;
background: linear-gradient(to bottom right, #B05574, #F87E7B);
border-radius: 3px;
padding: 5px 5px;
/*
position: relative; 
top: 50%;
*/
}

.login-button-input {
color: white;
border: none;
margin-left: 4px;
height: ;
}

/*Modal*/
h4 {
font-weight: bold;
color: #fff;
}

.close {
color: #fff;
transform: scale(1.2)
}
.modal-content {
font-weight: bold;
background: linear-gradient(to bottom right,#F87E7B,#B05574);
}
.form-control {
margin: 1em 0;
}
.form-control:hover, .form-control:focus {
box-shadow: none;  
border-color: #fff;
}
.username, .password, .FileName{
border: none;
border-radius: 0;
box-shadow: none;
border-bottom: 2px solid #eee;
padding-left: 0;
font-weight: normal;
background: transparent;  
color: white;
}

.form-control::-webkit-input-placeholder {
color: #eee;  
}
.form-control:focus::-webkit-input-placeholder {
font-weight: bold;
color: #fff;
}
.login {
padding: 6px 20px;
border-radius: 20px;
background: none;
border: 2px solid #FAB87F;
color: #FAB87F;
font-weight: bold;
transition: all .5s;
margin-top: 1em;
}
.login:active{
background: #FAB87F;
color: #fff;
}
.login:hover {
background: #FAB87F;
color: #fff;
}

.divTag{
background: #333333;
padding-top: ;
margin-top: ;
padding-bottom: 50px;
bottom: ;
left: 50%;
}

.textContent {
border: none;
border-radius: 2px;
box-shadow: none;
border-bottom: 2px solid #35FFFF;
padding-left: 0;
font-weight: normal;
background: black;  
color: skyblue;
height: 300px;
width: 300px;
outline-style: groove;
}

.h3-Title {
color: skyblue;

text-align: center;

}
</style>
</head>
<body>

<div class="divTag">
<center>
<h3 class="h3-Title">Write Texts to File</h3>
<form action="#" method="get">

<span>File Name = </span>
<input name="FileName"  type="text" class="FileName" placeholder="my-files/File.txt" value="<?php echo("$FileName"); ?>" required>
<br/>

<span>Text Count = </span>
<input type="text" class="FileName" placeholder="0" value="<?php echo("$TextCount"); ?>" readonly>
<br/><br/>

<textarea name="textContent" class="textContent" type="text" placeholder="Enter Some Text!">
<?php echo("$ReadFile"); ?>
</textarea>
<br/>

<input class="btn login" name="submit" type="submit" value="Save" />

<input class="btn login" type="reset" value="Reset" />

<button formaction="Read-File.php" class="btn login">Read</button>
<br/><br/>

<a onclick="return confirm('Preview File?')"  class="btn login" href="<?php echo("$FileName"); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>

<a onclick="downloadFile()" class="btn login" href="#"><i class="fa fa-download"></i></a>

</form>
</center>
</div>

<?php
// Include 'File-Downloading.php' Script
include("include/File-Downloading.php");
?>
</body>
</html>