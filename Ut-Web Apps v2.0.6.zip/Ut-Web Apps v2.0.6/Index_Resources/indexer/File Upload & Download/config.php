<?php
// Database
include("../../includes/config.php");

//Get Domain URL
 $GetDomainURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; 

?>

<?php
// Configuration
$server = "$host";
$dbuser = "$user";
$dbpass = "$password";
$database = "$database";

$conn = mysqli_connect($server, $dbuser, $dbpass, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

$base_url = "$GetDomainURL/Index_Resources/indexer/File%20Upload%20&%20Download/"; // Website url

?>