// Playlist ID
    var listID = 'PLMC9KNkIncKtPzgY-5rmhvj7fax8fdxoj';
// Number of videos in playlist    
    var numberOfVideos = 2000;
// Random number generator 
    var randomizer = Math.floor(Math.random() * numberOfVideos + 1);
// Embed video code
    document.writeln('<iframe id="random-video" src="//www.youtube.com/embed/videoseries?list=' + listID + '&index=' + randomizer + '&autoplay=1&controls=1&modestbranding=1&showinfo=1" frameborder="1" allowfullscreen></iframe>');

//Fullscreen stuff (optional)
    $(function(){
        $('#random-video').css({ width: $(window).innerWidth() + 'px', height: $(window).innerHeight() + 'px' });
        $(window).resize(function(){
          $('#random-video').css({ width: $(window).innerWidth() + 'px', height: $(window).innerHeight() + 'px' });
        });
    });
