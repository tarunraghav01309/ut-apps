<?php 
 $videoURL = $_GET['url'];
  $convertedURL = str_replace("view?usp=drivesdk","preview", $videoURL);
?>