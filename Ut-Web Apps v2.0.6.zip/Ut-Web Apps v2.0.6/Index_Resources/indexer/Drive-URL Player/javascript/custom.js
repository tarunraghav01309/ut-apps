$('iframe').hide();
$(document).ready(function(){
  $('form').submit(function(e){
    e.preventDefault();
    let getURL = $('.url').val();
    let newURL = getURL.replace("view?usp=drivesdk", "preview");
    $('iframe').attr( "src", newURL ).show();
  });
});