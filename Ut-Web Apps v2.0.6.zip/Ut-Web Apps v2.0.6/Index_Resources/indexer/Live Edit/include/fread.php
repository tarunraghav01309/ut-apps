<?php
// Define FileName
$FileName = "include/HTML+CSS+JS.txt";
?>

<?php 
// Read CSS.txt
$FileName1 = "include/CSS.txt";
$ModeR = "r";
$data1 = fopen("$FileName1", "$ModeR"); 
$ReadCSS = fread($data1, filesize($FileName1));
fclose($data1); 

// Read HTML.txt
$FileName2 = "include/HTML.txt";
$ModeR = "r";
$data2 = fopen("$FileName2", "$ModeR"); 
$ReadHTML = fread($data2, filesize($FileName2));
fclose($data2); 

// Read JS.txt
$FileName3 = "include/JS.txt";
$ModeR = "r";
$data3 = fopen("$FileName3", "$ModeR"); 
$ReadJS = fread($data3, filesize($FileName3));
fclose($data3); 
?> 

<div style='display:none;'>
CSS = 
<?php echo("$ReadCSS"); ?>
<br/>

HTML = 
<?php echo("$ReadHTML"); ?>
<br/>

JS =
<?php echo("$ReadJS"); ?>

</div>
