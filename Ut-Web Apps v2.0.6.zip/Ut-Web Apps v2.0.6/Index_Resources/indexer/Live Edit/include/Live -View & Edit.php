<?php
$file = 'HTML+CSS+JS.txt';

// check if form has been submitted
if (isset($_POST['submit']))
{
echo "<script type='text/javascript'>alert(' Saved Successfully!');</script>";
}

// check if form has been submitted
if (isset($_POST['text']))
{
    // save the text contents
    file_put_contents($file, $_POST['text']);

echo "<script type='text/javascript'>location.href = 'Live -View & Edit.php';</script>";
    exit();
}

// read the textfile
$text = file_get_contents($file);

?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- CSS Code -->
<style>
body {
  height: 100%;
  background:skyblue;
}

div{
border:2px solid red;
}

textarea {
  width: 100%;
  height: 100vh;
  color:orange;
  background:#333333;
}

h3{
text-align:center;
color:white;
background-color:#FF3333;
}

.button1{
position: absolute; 
right: 60;
margin:3px;
top:72px;
}

.button2{
position: absolute; 
right: 10;
margin:3px;
top:72px;
}
</style>

<div>
<h3>Live -View & Edit</h3>
<!-- HTML form -->
<form action="" method="post">

<input onClick="savebutton()" name="submit" class="button1" type="submit" value="Save"/>

<input class="button2" type="reset" value="Reset" onClick="resetbutton()"/>

<textarea name="text"><?php echo htmlspecialchars($text) ?></textarea>
</form>
</div>
<br/>
</html>

<script type="text/javascript">
function resetbutton()
{
var con=confirm("Do you really want to reset?");
}
</script>
