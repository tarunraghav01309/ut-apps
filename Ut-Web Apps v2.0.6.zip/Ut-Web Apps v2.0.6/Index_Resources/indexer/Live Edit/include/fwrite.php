<?php

if (isset($_POST['submit'])) { 

$myfile4 = fopen("include/CSS.txt", "w") or die("Unable to open file!");
$CSS = $_POST['CSS'];
fwrite($myfile4, $CSS);
fclose($myfile4);

$myfile3 = fopen("include/HTML.txt", "w") or die("Unable to open file!");
$HTML = $_POST['HTML'];
fwrite($myfile3, $HTML);
fclose($myfile3);

$myfile2 = fopen("include/JS.txt", "w") or die("Unable to open file!");
$JS = $_POST['JS'];
fwrite($myfile2, $JS);
fclose($myfile2);

//Combine HTML+CSS+JS Code
$myfile = fopen("include/HTML+CSS+JS.txt", "w") or die("Unable to open file!");

$Header = "<!Doctype html>\n<html>\n<head>\n";
fwrite($myfile, $Header);

$LinkTag = "<link rel='stylesheet' type='text/css' href='style.css'>\n<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>\n";
fwrite($myfile, $LinkTag);

$CSS = $_POST['CSS'];
$lineBreak2 = "\n";
$StyleTag = "<style>$lineBreak2$CSS$lineBreak2</style>";
$CSS = "$StyleTag";
fwrite($myfile, $CSS);

$Head = "\n</head>\n<body>\n";
fwrite($myfile, $Head);

$HTML = $_POST['HTML'];
$lineBreak1 = "\n";
$HTML ="$HTML$lineBreak";
fwrite($myfile, $HTML);

$JS = $_POST['JS'];
$lineBreak3 = "\n";
$ScriptTag = "$lineBreak3<script>$lineBreak3$JS$lineBreak3</script>";
$JS = "$ScriptTag";
fwrite($myfile, $JS);


$ScriptTag = "\n<script src='script.js'></script>\n";
fwrite($myfile, $ScriptTag);

$Footer = "</body>\n</html>\n";
fwrite($myfile, $Footer);

fclose($myfile);


echo "<script type='text/javascript'>alert(' Saved Successfully!');
location.href='index.php';
</script>";
}
else 
{
$error="Failed to Save, Please try again!";
}


?>



