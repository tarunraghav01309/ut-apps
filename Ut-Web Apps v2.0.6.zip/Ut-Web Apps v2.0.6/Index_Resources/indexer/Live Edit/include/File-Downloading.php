<!--
<button onclick="downloadFile()">
Download
</button>
-->

<script>
function downloadFile() {

//For change file name before Downloading!
var filename = prompt("File Downloading!\n[Note: change filename if required.]", "<?php echo("$FileName"); ?>");
  if (filename != null) {
    
axios({
url: '<?php echo("$FileName"); ?>',
method: 'POST',
responseType: 'blob'
})
.then((response) => {
const url = window.URL
.createObjectURL(new Blob([response.data]));
const link = document.createElement('a');
link.href = url;
link.setAttribute('download', "" + filename + "");
document.body.appendChild(link);
link.click();
document.body.removeChild(link);
})
}

// on press Ok
if (filename != null) {
    alert("Downloading...");
}

// on press Cancel
else {
    alert("Cancelled.");
}

}

//Add or Include External 'axios' script URL for Download File [Required]
var script = document.createElement('script');
script.type = 'text/javascript';
script.src = 'https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.min.js';
document.body.appendChild(script);

</script>
