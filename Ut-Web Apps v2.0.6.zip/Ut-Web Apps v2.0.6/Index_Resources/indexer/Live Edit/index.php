<?php
// Hide All PHP Errors
error_reporting(0);
?>
<div style="display:none;">
<?php include("include/fread.php"); ?>
<?php include("include/fwrite.php"); ?>
</div>

<!Doctype html>
<html>
<title>Live Edit</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<meta name="description" content="Live Editor">
<meta name="robots" content="index, follow">
<meta name="keywords"
content="Live Editor, Text Editor, Web Editor, HTML, HTML Editor, CSS, CSS Editor, JS, JS Editor, JavaScript, JavaScript Editor">
<meta name="author" content="Mohammad Khaled Abu Mattar">
<meta name="theme-color" content="#000000">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
<style>
@import url("https://fonts.googleapis.com/css?family=Montserrat");

.fa{
color:#FF3333;
background: #333333;
}

* {
box-sizing: border-box
}

body,
html {
height: 98%;
margin: 0;
font-family: "Montserrat", sans-serif;
}

/********************/

.floating {
position: fixed;
right: 24px;
transition: all 500ms ease 0s;
z-index: 7;
display: flex;
flex-direction: column;
-webkit-box-pack: end;
justify-content: flex-end;
align-items: flex-end;
bottom: 49px;
}

.floating__btn {
width: 3rem;
height: 3rem;
border-radius: 50%;
user-select: none;
pointer-events: all;
border: 0;
cursor: pointer;
}

.floating__btn:first-child {
margin-bottom: 1rem;
background-color: #E53935;
}

.floating__btn svg {
display: block;
border-radius: 50%;
width: 100%;
height: 100%;
}

.floating__btn #install_app {
-webkit-transform: scale(0.66);
transform: scale(0.66);
-webkit-transform-origin: center;
transform-origin: center;
fill: white;
}

/***********************/

#header {
color: #252525;
}

#title {
font-size: 2rem;
line-height: 1.67;
letter-spacing: .7px;
text-align: center;
user-select: none;
}

.tablink {
background-color: #555;
color: white;
float: left;
border: none;
outline: none;
cursor: pointer;
padding: 14px 16px;
font-size: 17px;
width: 25%;
border-radius: 0px;
}

.tablink:focus {
outline: none;
}

.tablink:hover {
background-color: #777;
}

.tabcontent {
height: 71vh;
display: none;
}

.tabcontent__preview {
padding: 20px;
padding-top: 50px;
}

#HTML__editor,
#CSS__editor,
#JS__editor {
position: relative;
height: 100%;
width: 100%;
}

.text {
visibility: hidden;
position: absolute;
width: 0;
height: 0;
}

footer {
background-color: #fff;
text-align: center;
padding: 4em 0 2em 0;
font-size: 0.8em;
}

footer mark {
background-color: #4158D0;
background-image: linear-gradient(43deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
}

footer a {
text-decoration: none;
color: #d52128;
}
</style>
</head>
<body>

<header id="header">
<h1 id="title">
<svg viewBox="0 0 300 300" width="40" class="" fill="#d52128">
<path
d="m1877 2568c-183-227-346-430-362-451-32-40-64-54-88-40-8 4-33 31-54 58-29 37-54 90-93 200-50 140-57 154-111 213-33 34-87 104-120 155-77 116-79 118-69 71 7-29 4-59-11-119-12-44-22-81-23-83-2-1-35 16-73 38-55 31-74 48-88 79-11 26-36 52-71 77-30 20-56 35-58 33s-7-45-12-95c-7-68-6-99 3-120 7-16 12-46 13-66 0-47 98-295 185-468 79-158 163-365 175-434 5-28 17-74 27-103 17-52 17-52-11-123-15-39-44-89-63-112s-41-54-49-69c-20-39-71-114-86-127-7-5-26-12-43-14-26-3-32-10-56-73-15-38-72-144-128-235l-101-165 40-40 40-41-20-160c-11-87-20-164-20-171s13-9 39-6c34 5 40 2 61-27 14-19 25-53 28-81s10-49 16-49c7 0 40 9 74 21 70 23 47-7 197 269 138 253 207 355 329 486 71 77 80 77 114 5 11-23 32-44 57-57 39-20 40-23 62-115 12-52 25-104 28-115 4-20 182-170 191-162 2 2-4 46-12 96-9 51-14 98-11 106 6 15 59 28 81 20 7-3 27-24 44-47 20-28 53-54 97-77 78-41 85-37 85 56 0 64 11 84 45 84 16 0 26-10 37-38 13-34 20-39 76-55 34-9 66-17 71-17s14 30 20 66c13 73 18 61-70 191-26 38-70 114-97 169-63 124-84 153-149 203-42 33-53 48-58 78-3 21-8 47-10 58s-36 69-75 128c-63 98-70 113-70 159 0 47 4 55 48 102 27 28 68 89 93 136 53 103 183 298 293 440 118 152 124 161 219 315 79 126 87 145 87 189v49l-77-75c-49-47-92-80-117-88-37-12-39-11-62 16-27 32-27 31 3 226 13 88 14 110 3 122-7 9-16 16-21 16-4 0-158-186-342-412z"
transform="matrix(.1 0 0 -.1 0 300)"></path>
</svg>
Live Edit
</h1>
</header>

<button class="tablink" onclick="openPage('HTML__tab', this, '#E44D26')" id="default">HTML</button>
<button class="tablink" onclick="openPage('CSS__tab', this, '#1572B6')">CSS</button>
<button class="tablink" onclick="openPage('JS__tab', this, '#F0DB4F')">JS</button>
<button class="tablink" onclick="openPage('Preview', this, '#212121')">Preview</button>

<form action="#" method="post">
<div class="floating">

<button onclick="location.href='include/Live -View & Edit.php'; return false;" style="margin-left: 121px;
    margin-top: 19px;
    width: 50px;
    height: 46px;   
    color: white;
    background:#333333;
    font-size:14px;
    font-weight:700;" ><i class="fa fa-eye fa-2x"></i>view</button>


<button onclick="downloadFile(); return false;" style="margin-left: 121px;
    margin-top: 19px;
    width: 50px;
    height: 46px;   
    color: white;
    background:#333333;
    font-size:14px;
    font-weight:700;" ><i class="fa fa-download fa-2x"></i>down.</button>


<button name="submit" style="margin-left: 121px;
    margin-top: 19px;
    width: 50px;
    height: 46px;   
    color: white;
    background:#333333;
    font-size:14px;
    font-weight:700;" ><i class="fa fa-save fa-2x"></i>save</button>

</div>

<div id="HTML__tab" class="tabcontent">
<div id="HTML__editor" data-target="#HTML"></div>
<textarea class="text" id="HTML" name="HTML" data-type=".HTML"><?php echo("$ReadHTML"); ?></textarea>
</div>

<div id="CSS__tab" class="tabcontent">
<div id="CSS__editor" data-target="#CSS"></div>
<textarea class="text" id="CSS" name="CSS" data-type="style"><?php echo("$ReadCSS"); ?></textarea>
</div>

<div id="JS__tab" class="tabcontent">
<div id="JS__editor" data-target="#JS"></div>
<textarea class="text" id="JS" name="JS" data-type="script"><?php echo("$ReadJS"); ?></textarea>
</div>
</form>

<div id="Preview" class="tabcontent tabcontent__preview">
<div class="preview">
<style></style>
<div class="HTML"></div>
<script></script>
</div>
</div>

<footer>
<p>
All Copyrights Reserved &#169; 2020
<script>
new Date().getFullYear() > 2020 && document.write(" - " + new Date().getFullYear());
</script>, By <br/><a class="" href="https://mkabumattar.github.io/">Mohammad
Khaled Abu Mattar and Tarun Raghav</a>
</p>
</footer>

<script>
function openPage(pageName, elmnt, color) {
var i, tabcontent, tablinks;
tabcontent = document.getElementsByClassName("tabcontent");
for (i = 0; i < tabcontent.length; i++) {
tabcontent[i].style.display = "none";
}
tablinks = document.getElementsByClassName("tablink");
for (i = 0; i < tablinks.length; i++) {
tablinks[i].style.backgroundColor = "";
}
document.getElementById(pageName).style.display = "block";
elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("default").click();

function editor() {
if ($('#HTML__editor').length) {
var targetHtml = $('#HTML__editor').data('target');
var editorHtml = ace.edit("HTML__editor");
editorHtml.setValue($(targetHtml).val());
editorHtml.setTheme("ace/theme/nord_dark");
editorHtml.getSession().setMode("ace/mode/html");
editorHtml.getSession().setUseWrapMode(true);
editorHtml.on('change', function () {
$(targetHtml).val(editorHtml.getValue());
$(targetHtml).trigger('change');

});
}
if ($('#CSS__editor').length) {
var targetCss = $('#CSS__editor').data('target');
var editorCss = ace.edit("CSS__editor");
editorCss.setValue($(targetCss).val());
editorCss.setTheme("ace/theme/nord_dark");
editorCss.getSession().setMode("ace/mode/css");
editorCss.getSession().setUseWrapMode(true);
editorCss.on('change', function () {
$(targetCss).val(editorCss.getValue());
$(targetCss).trigger('change');
});
}
if ($('#JS__editor').length) {
var targetJs = $('#JS__editor').data('target');
var editorJs = ace.edit("JS__editor");
editorJs.setValue($(targetJs).val());
editorJs.setTheme("ace/theme/nord_dark");
editorJs.getSession().setMode("ace/mode/javascript");
editorJs.getSession().setUseWrapMode(true);
editorJs.on('change', function () {
$(targetJs).val(editorJs.getValue());
$(targetJs).trigger('change');
});
}
}

function livePreview() {
if ($('.preview').length) {

$('#HTML,#CSS,#JS').on('change', function () {
var el = $(this);
var target = el.data('type');
var val = el.val();
$('.preview').find(target).html(val);
});

}
}

editor();
livePreview();

$(window).on('load', function () {
if ($('.preview').length) {
$('#HTML,#CSS,#JS').trigger('change');
}
});
</script>


<?php
// Include 'File-Downloading.php' Script
include("include/File-Downloading.php");
?>
</body>
</html>
