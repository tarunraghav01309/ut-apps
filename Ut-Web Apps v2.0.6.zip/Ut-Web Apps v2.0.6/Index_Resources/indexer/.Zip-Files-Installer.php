<?php
// PHP Errors Reporting Turn Off 
    error_reporting(0);
?>
<?php
// UPLOAD FILE FROM DEVICE (Local)

/* Simple script to upload a zip file to the webserver and have it unzipped
  Saves tons of time, think only of uploading Wordpress to the server
  Thanks to c.bavota (www.bavotasan.com)
  I have modified the script a little to make it more convenient
  Modified by: Johan van de Merwe (12.02.2013)
 */

if ($_FILES["zip_file"]["name"]) {
    $filename = $_FILES["zip_file"]["name"];
    $source = $_FILES["zip_file"]["tmp_name"];
    $type = $_FILES["zip_file"]["type"];

    $name = explode(".", $filename);
    $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
    foreach ($accepted_types as $mime_type) {
        if ($mime_type == $type) {
            $okay = true;
            break;
        }
    }

    $continue = strtolower($name[1]) == 'zip' ? true : false;
    if (!$continue) {
        $message = "The file you are trying to upload is not a .zip file. Please try again.";
    }

    /* PHP current path */
    $path = dirname(__FILE__) . '/';  // absolute path to the directory where zipper.php is in
    $filenoext = basename($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
    $filenoext = basename($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)

    $targetdir = $path . $filenoext; // target directory
    $targetzip = $path . $filename; // target zip file

    /* create directory if not exists, otherwise overwrite */
    /* target directory is same as filename without extension */

 //   if (is_dir($targetdir))
      //  rmdir_recursive($targetdir);
  //  mkdir($targetdir, 0777);


    /* here it is really happening */

    if (move_uploaded_file($source, $targetzip)) {
        $zip = new ZipArchive();
        $x = $zip->open($targetzip);  // open the zip file to extract
        if ($x === true) {

// Get Current Path or Directory Name 
$path = pathinfo(realpath($filename), PATHINFO_DIRNAME);

                 $zip->extractTo($path);// place in the directory with same name  
            $zip->close();

            unlink($targetzip);
        }
        $message = "<strong>Your File ($filename) was uploaded and unpacked successfully.</strong>";
    } else {
        $message = "<strong>Uploading Failed! Please Try again, and upload only a '.zip' File.</strong>";

    }
}

?>
<?php
// UPLOAD FILE FROM REMOTE URL

/*
	1) upload this file into the folder you'd like to extract the content of the downloaded .zip file.
	2) run the script in you browser. i.e. http://localhost/downunzip.php
	3) after the script was executed sucesfully, login thru ftp and remove this script
*/

/* Get File URL by input form*/
 $FileURL = $_GET['FileURL'];

	$download_url = "$FileURL"; // url to zip file you want to download
	$delete = "yes"; // if you DO NOT want the .zip file to be deleted after it was extracted set "yes" to "no".

/* don't touch nothing after this line */
	$fileName = "file.zip";
	$script = basename($_SERVER['PHP_SELF']);

// download the file 
	file_put_contents($fileName, fopen($download_url, 'r'));

// extract file content 
	$path1 = pathinfo(realpath($fileName), PATHINFO_DIRNAME); // get the absolute path to $fileName (leave it as it is)

	$zip1 = new ZipArchive;
	$res = $zip1->open($fileName);

	if ($res === TRUE) {
	  $zip1->extractTo($path1);
	  $zip1->close();

// Delete Zip file after unzip
     unlink($fileName);

	  $Message1 = "<strong>Your File was uploaded and unpacked successfully from URL: ($FileURL).</strong>";
	  if ($delete == "yes") { unlink($file); } else { $Message2 =  "remember to delete <strong>$file</strong> & <strong>$script</strong>!"; }

	} else {
	  echo "<strong>Uploading Failed from URL: ($FileURL)</strong>";
	}

?>

<!DOCTYPE html>
<html>
<title>Zip Files Installer</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

#myDIV{
/*
width: 100%;
padding: 50px 0;
*/
text-align: center;
background-color: lightblue;
margin-top: 20px;
display: none;
}

strong,p {
text-align: center;
background-color: lightblue;
margin-top: 20px;
}

input[type="file"] { 
  z-index: -1;
  position: absolute;
  opacity: 0;
}

input:focus + label {
  outline: 2px solid;
}

body {
font-family: Arial, Helvetica, sans-serif;
margin: 0;
}

html {
box-sizing: border-box;
}

*, *:before, *:after {
box-sizing: inherit;
}

.column {
float: left;
width: 33.3%;
margin-bottom: 16px;
padding: 0 8px;
}

.card {
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
margin: 8px;
}

.about-section {
padding: 2px;
text-align: center;
background-color: #474e5d;
color: white;
}

.container {
padding: 0 16px;
}

.container::after, .row::after {
content: "";
clear: both;
display: table;
}

.title {
color: grey;
}

.button {
border: none;
outline: 0;
display: inline-block;
padding: 8px;
color: white;
background-color: #000;
text-align: center;
cursor: pointer;
width: 100%;
}

.button:hover {
background-color: #555;
}

@media screen and (max-width: 650px) {
.column {
width: 100%;
display: block;
}
}
</style>
</head>
<body>

<!-- PAGE TITLE-->
<div class="about-section">
<h1 style="color: ; text-align:center;">Zip Files-Installer</h1>
</div>


<!-- ALL-COLUMNS SECTION (Wrapper)-->
<h2 style="text-align:center"></h2>
<div class="row">



<!-- Column 001-->
<div class="column">
<div class="card">

<div class="file-upload">
<center>
<form enctype="multipart/form-data" method="post" action="">
  <label for="file-upload">
    <img src="../../Images/Local-Zip-Upload-icon.png" alt="Upload Zip|Local" style="height:200px;width:200px;">
  </label>
  <input name="zip_file" id="file-upload" type="file" required/>

</center>
</div>


<div class="container">
<h2>Upload Zip | from Device</h2>
<p class="title"><?php if ($message) echo "<p>$message</p>"; ?></p>
<div id="file-upload-filename"></div>
<br/><br/>

<!-- BUTTON STYLE & Href -->
<style>
.button001 {
display: inline-black;
padding: 10px 20px;
text-align: center;
text-decoration: none;
color: black;
border:1px solid black;
background-color: skyblue;
border-radius: 6px;
outline: none;

/*.button */
border: none;
outline: 0;
display: inline-block;
padding: 8px;
color: #35FFFF;
background-color: #365667;
text-align: center;
cursor: pointer;
width: 100%;
}

.div {
margin: 6%;
padding: 0%;
box-sizing: border-box;
}
</style>

<input type="submit" name="submit" id="myDiv001" class="button001" value="Upload &rarr;"/>
<div id="loader001" style="display:none;text-align: center; background: skyblue;padding:5px"></div>

</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
var myVar;
$( "#myDiv001" ).click(function() {
myFunction(this);
});
function myFunction(div) {
$("#loader001").toggle();
$(div).toggle();
}
});
</script>
<br/><br/>
</div>
</div>
</div>


<!-- Column 002-->
<div class="column">
<div class="card">
<center>

<img src="../../Images/URL-File-Upload-icon.png" alt="Upload Zip|Local" style="height:227px;width:200px;">
</center>
<div class="container">
<h2>Upload Zip | from URL<input type="button" onclick="myFunctionShow()" value="Upload Report" /></h2>

<div id="myDIV">
<h2 class="title">Uploaded File Report</h2>
<p><?php echo("$Message1 $Message2"); ?></p>
</div>

<p class="title"></p>
<form action="#" method="get">
<input name="FileURL"  type="text" style="width: 100%;" placeholder="Please Enter URL" value="" required>
<br/><br/>

<!-- BUTTON STYLE & Href -->
<style>
.button002 {
display: inline-black;
padding: 10px 20px;
text-align: center;
text-decoration: none;
color: black;
border:1px solid black;
background-color: skyblue;
border-radius: 6px;
outline: none;

/*.button */
border: none;
outline: 0;
display: inline-block;
padding: 8px;
color: #35FFFF;
background-color: #365667;
text-align: center;
cursor: pointer;
width: 100%;
}

.div {
margin: 6%;
padding: 0%;
box-sizing: border-box;
}
</style>

<input name="submit" type="submit" id="myDiv002" class="button002" value="Upload" />

<div id="loader002" style="display:none;text-align: center; background: skyblue;padding:5px">Uploading- Please Wait.... &rarr;</div>
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
var myVar;
$( "#myDiv002" ).click(function() {
myFunction(this);
});
function myFunction(div) {
$("#loader002").toggle();
$(div).toggle();
}
});
</script>
<br/><br/>
</div>
</div>
</div>




<!-- FOOTER -->
</div>

<script>
function myFunctionShow() {
var x = document.getElementById("myDIV");
if (x.style.display === "block") {
x.style.display = "none";
} else {
x.style.display = "block";
}
}
</script>
<script>
var input = document.getElementById( 'file-upload' );
var infoArea = document.getElementById( 'file-upload-filename' );

input.addEventListener( 'change', showFileName );

function showFileName( event ) {
  
  // the change event gives us the input it occurred in 
  var input = event.srcElement;
  
  // the input has an array of files in the `files` property, each one has a name that you can use. We're just using the name here.
  var fileName = input.files[0].name;
  
  // use fileName however fits your app best, i.e. add it into a div
  infoArea.textContent = 'File name: ' + fileName;
}
</script>
</body>
</html>