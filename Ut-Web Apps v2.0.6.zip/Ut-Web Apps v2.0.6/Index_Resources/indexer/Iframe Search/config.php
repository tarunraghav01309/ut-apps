<?php
 $url = $_GET['url'];

//Encode URL after domain name only
$url = preg_replace_callback('#://([^/]+)/([^?]+)#', function ($match) {
                return '://' . $match[1] . '/' . join('/', array_map('rawurlencode', explode('/', $match[2])));
            }, $url);
?>