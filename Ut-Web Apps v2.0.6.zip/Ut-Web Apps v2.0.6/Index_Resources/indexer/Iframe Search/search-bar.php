<style>
.search-bar {
background: #ededed;
border: 10px solid #ededed;
border-radius: 10px;
width: 80%;
}

.search-icon {
padding-bottom: 0px;
height: 37px;
width: 45px;
border: 1px solid skyblue;
border-radius: 5px;
}

.search-icon:active {
color: skyblue;
background-color: blue;
}
.search-icon:hover {
padding-bottom: 0px;
height: 39px;
width: 47px;
background-color: skyblue;
border: 2px solid blue;
border-radius: 6px;
}

</style>
<div class="div-search-border">
    <input class="search-bar" type="url" name="url" placeholder="Type web address" value="">
<button class="search-icon" type="submit" value="Search">&#128269;
</button>
</div>