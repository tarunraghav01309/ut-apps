<html>
<head>
    <title>Iframe Search</title>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<link rel="stylesheet" href="#" />
<style>
.div-style {
padding-top:20%;
}

.p-style {
font-size: 9px;
}

.div-search-border {
border:;
}
</style>
  </head>
  <body>
<center>

<div class="div-style">

<!-- Iframe Rainbow Text -->
<?php include "Iframe-rainbow-text.php" ?>
<div class="p-style">
search
</div>
<br/>
  <form action="iframe-results.php" method="get">

<!-- Search Bar -->
<?php include "search-bar.php" ?>

<br/>
  </form>
</div>
</center>
  </body>
</html>
