<!DOCTYPE html>
<html>
<head>

<style>
.rainbow-text, span{
	font-family: Arial;
	font-weight: bold;
	font-size: 60px;
        padding: 0px;
	text-shadow: #A3A3A3 4px 2px 4px;
}
.rainbow-text .block-line > span {
	display: inline-block;
}

</style>
</head>
<body>
<span class="block-line">
<span>
<span style="color:#9400D3;">I</span>
<span style="color:#4B0082;">f</span>
<span style="color:#0000FF;">r</span>
<span style="color:#00FF00;">a</span>
<span style="color:#FFFF00;">m</span>
<span style="color:#FF7F00;">e</span>
</span>
</span>

</body>
</html>