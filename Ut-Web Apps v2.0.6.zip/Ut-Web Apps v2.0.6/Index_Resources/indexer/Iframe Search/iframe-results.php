<html>
<head>
    <title>Iframe Search</title>
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<!-- PHP Code -->
<?php include 'config.php'; ?>

<style>
.search-bar {
background: #ededed;
border: 10px solid #ededed;
border-radius: 10px;
width: 80%;
}

.search-icon {
padding-bottom: 0px;
height: 37px;
width: 45px;
border: 1px solid skyblue;
border-radius: 5px;
}

.search-icon:active {
color: skyblue;
background-color: blue;
}
.search-icon:hover {
padding-bottom: 0px;
height: 39px;
width: 47px;
background-color: skyblue;
border: 2px solid blue;
border-radius: 6px;
}

</style>
</head>
  <body>
<center>
  <form action="iframe-results.php" method="get">

<div class="div-search-border">
    <input class="search-bar" type="url" name="url" placeholder="Type web address" value="<?php echo $url; ?>">
<button class="search-icon" type="submit" value="Search">&#128269;
</button>
</div>

  </form>

  <iframe src="<?php echo $url; ?>" style="width: 100%; height: 100%;" frameborder="0" >
  </iframe>

</center>
  </body>
</html>
