<!DOCTYPE html>
<html lang="en">
<head>
  <title>Video-URL Plyr +</title>
<link rel="icon" type="image/png" href="Images/player-logo.png"/>
    <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- PHP Code -->
<?php include 'config.php';?>

<!-- remove-000webhost-Banner-->
<script src="include/remove-000webhost-Banner.js"></script>

<style>
/*
​    body {
     margin: 0;
    }

    .plyr {
    height: 100%;
    width :100%;
    }
*/
</style>
</head>
<body >
<div class="video-wrapper">

 <video controls crossorigin playsinline
   data-poster="<?php echo $VideoPoster; ?>" class="vid1" id="player">

            <source
              src="<?php echo $VideoSrc1; ?>"
              type="<?php echo $VideoType1; ?>"
              size="<?php echo $VideoQuality1; ?>"
            />
            <source
              src="<?php echo $VideoSrc2; ?>"
              type="<?php echo $VideoType2; ?>"
              size="<?php echo $VideoQuality2; ?>"
            />
            <source
              src="<?php echo $VideoSrc3; ?>"
              type="<?php echo $VideoType3; ?>"
              size="<?php echo $VideoQuality3; ?>"
            />
           <source
              src="<?php echo $VideoSrc4; ?>"
              type="<?php echo $VideoType4; ?>"
              size="<?php echo $VideoQuality4; ?>"
            />

       <track
              kind="<?php echo $kind1; ?>"
              label="<?php echo $label1; ?>"
              srclang="<?php echo $srclang1; ?>"
              src="<?php echo $VideoTrack1; ?>"
              <?php echo $default1; ?>
            />

       <track
              kind="<?php echo $kind2; ?>"
              label="<?php echo $label2; ?>"
              srclang="<?php echo $srclang2; ?>"
              src="<?php echo $VideoTrack2; ?>"
              <?php echo $default2; ?>
            />

</video>

<!-- Fallback Error for unsupported Video Type -->
<script>
var sources = document.querySelectorAll('source');
var source_errors = 0;
for (var i = 0; i < sources.length; i++) {
  sources[i].addEventListener('error', function(e) {
    if (++source_errors >= sources.length)
      fallBack();
  });
}

function fallBack() {
  document.body.removeChild(document.querySelector('video'));
  document.body.appendChild(document.createTextNode('Error- No video with supported media, source  and MIME type found...'));
}

</script>
</div>

<!-- Add Plyr demo CSS and JS
 <link rel="stylesheet" href="https://cdn.plyr.io/3.6.2/demo.css" />
-->
  <script src="https://cdn.plyr.io/3.6.2/demo.js" crossorigin="anonymous"></script>
 

<!-- Add Plyr Newly Released CSS and JS -->
<link rel="stylesheet" href="https://cdn.plyr.io/3.6.12/plyr.css" />
<script src="https://cdn.plyr.io/3.6.9/plyr.js"></script>

 


<!-- Custom Controls plyr-config.js -->
<script src="https://cdn.jsdelivr.net/gh/tarunraghav01309/Red-Plyr_v1.3/plyr-config.js" crossorigin="anonymous"></script>
<!-- Custom Theme Colour plyr-config.css -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/tarunraghav01309/Red-Plyr_v1.3/plyr-config.css" />
 </body>
 </html>