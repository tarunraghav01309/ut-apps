<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <title>Video-URL Plyr +</title>
<link rel="icon" type="image/png" href="Images/player-logo.png"/>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
<style>
a{
 display: none;
}

  .input_url_style {
   color: #35FFFF;
   background: #333333;
   border: 1px solid white;
   width:100%;
   }

/* NAVIGATION BAR */
* {box-sizing: border-box}

/* Set height of body and the document to 100% */
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}

/* Style tab links */
.tablink {
  background-color: black;
  color: #00ffff;
  float: left;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
  border: none;
}

.tablink:hover{
  background-color: red;
  color: white;
  border: none;
  outline: none;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: ;
  display: none;
  padding: 50px 30px;
  height: 100%;
}

#Video {background-color: ;}
#Poster {background-color: ;}
#Track {background-color: ;}
#Play {background-color: ;}

</style>
</head>

<button class="tablink" onclick="openPage('Video', this, '#FF3333')" id="defaultOpen">Video</button>
<button class="tablink" onclick="openPage('Poster', this, '#FF3333')">Poster</button>
<button class="tablink" onclick="openPage('Track', this, '#FF3333')">Track</button>
<button class="tablink" onclick="openPage('Play', this, '#FF3333')">Play</button>


<div id="Video" class="tabcontent">
  <!DOCTYPE html>
<html lang="en">
  <body style="color: white; background-color: #333333;">
    <br><br>
    <section>
<center>
      <div class="container" style="padding-bottom:10px;">
        <div class="row">
          <div class="col-lg-12">

<h2 style="color:#35FFFF; text-align: center; padding-bottom: 0px;">
Video
</h2>

<div style="background: ; border:1px solid #35FFFF; padding-top: 50px;">

<form name="form" action="video-url-plyr.php" method="get">

<p style="color: white; background: ;">Enter Video 1- URL</p>
  <input class="input_url_style" type="url" name="VideoSrc1" value="" placeholder="https://my-video-360p.mp4">
<br/><br/>

type
    <select name="VideoType1" style="padding:0px; width: 64px;">
      <option value="" hidden>Select</option>
      <option value="" disabled>Video Types-</option>
      <option value="">Off</option>
      <option value="video/mp4" selected>mp4</option>
      <option value="video/webm">webm</option>
      <option value="video/ogg">ogg</option>
    </select>

size
<select name="VideoQuality1" style="padding:0px; width: 66px;">
      <option value="" style="display:none;">Select</option>
        <option value="" disabled>Video Qualities-</option>
      <option value="" selected>Off</option>
      <option value="360" selected>360p</option>
      <option value="480">480p</option>
      <option value="576">576p</option>
      <option value="720">720p</option>
      <option value="1080">1080p</option>
      <option value="1440">1440p</option>
    </select>
<br/><br/>
</div>
<br/>

<div style="background: ; border:1px solid #35FFFF; padding-top: 50px;">
<p style="color: white; background: ;">Enter Video 2- URL</p>
  <input class="input_url_style" type="url" name="VideoSrc2" value="" placeholder="https://my-video-480p.mp4">
<br/><br/>

type
    <select name="VideoType2" style="padding:0px; width: 64px;">
      <option value="" hidden>Select</option>
      <option value="" disabled>Video Types-</option>
      <option value="" selected>Off</option>
      <option value="video/mp4">mp4</option>
      <option value="video/webm">webm</option>
      <option value="video/ogg">ogg</option>
    </select>

size
<select name="VideoQuality2" style="padding:0px; width: 66px;">
      <option value="" style="display:none;">Select</option>
        <option value="" disabled>Video Qualities-</option>
      <option value="" selected>Off</option>
      <option value="360">360p</option>
      <option value="480">480p</option>
      <option value="576">576p</option>
      <option value="720">720p</option>
      <option value="1080">1080p</option>
      <option value="1440">1440p</option>
    </select>
<br/><br/>
</div>
<br/>

<div style="border:1px solid #35FFFF; padding-top: 50px;">
<p style="color: white; background: ;">Enter Video 3- URL</p>
  <input class="input_url_style" type="url" name="VideoSrc3" value="" placeholder="https://my-video-720p.mp4">
<br/><br/>

type
    <select name="VideoType3" style="padding:0px; width: 64px;">
      <option value="" hidden>Select</option>
      <option value="" disabled>Video Types-</option>
      <option value="" selected>Off</option>
      <option value="video/mp4">mp4</option>
      <option value="video/webm">webm</option>
      <option value="video/ogg">ogg</option>
    </select>

size
<select name="VideoQuality3" style="padding:0px; width: 66px;">
      <option value="" style="display:none;">Select</option>
        <option value="" disabled>Video Qualities-</option>
      <option value="" selected>Off</option>
      <option value="360">360p</option>
      <option value="480">480p</option>
      <option value="576">576p</option>
      <option value="720">720p</option>
      <option value="1080">1080p</option>
      <option value="1440">1440p</option>
    </select>
<br/><br/>
</div>
<br/>

<div style="border:1px solid #35FFFF; padding-top: 50px;">
<p style="color: white; background: ;">Enter Video 4- URL</p>
  <input class="input_url_style" type="url" name="VideoSrc4" value="" placeholder="https://my-video-1080p.mp4">
<br/><br/>

type
    <select name="VideoType4" style="padding:0px; width: 64px;">
      <option value="" hidden>Select</option>
      <option value="" disabled>Video Types-</option>
      <option value="" selected>Off</option>
      <option value="video/mp4">mp4</option>
      <option value="video/webm">webm</option>
      <option value="video/ogg">ogg</option>
    </select>

size
<select name="VideoQuality4" style="padding:0px; width: 66px;">
      <option value="" style="display:none;">Select</option>
        <option value="" disabled>Video Qualities-</option>
      <option value="" selected>Off</option>
      <option value="360">360p</option>
      <option value="480">480p</option>
      <option value="576">576p</option>
      <option value="720">720p</option>
      <option value="1080">1080p</option>
      <option value="1440">1440p</option>
    </select>
<br/><br/>
</div>
<br/>
 <input onclick="openPage('Poster', this, '#FF3333')" class="btn btn-success" style="padding: 3px; padding-left: 20px; padding-right: 20px; text-align: center; cursor: pointer;" type="button" value="Next"/>
<br/><br/><br/>
            


          </div>
        </div>
      </div>    
</center>

    </section>

  </body>
</html>
<br/><br/>
</div>

<div id="Poster" class="tabcontent">
  <!DOCTYPE html>
<html lang="en">
  <body style="color: white; background-color: #333333;">
    <br><br>
    <section>
<center>
      <div class="container" style="padding-bottom:10px;">
        <div class="row">
          <div class="col-lg-12">

<h2 style="color:#35FFFF; text-align: center; padding-bottom: 0px;">
Poster
</h2>

            <div style="border:1px solid #35FFFF; padding-top: 50px;">


<p style="color: white; background: ;">Enter Poster- URL</p>
  <input class="input_url_style" type="url" name="VideoPoster" value="" placeholder="https://my-poster-image.jpg">
<br/><br/><br/><br/>
</div>
<br/>

 <input onclick="openPage('Track', this, '#FF3333')" class="btn btn-success" style="padding: 3px; padding-left: 20px; padding-right: 20px; text-align: center; cursor: pointer;" type="button" value="Next"/>
<br/><br/><br/>


          </div>
        </div>
      </div>    
</center>

    </section>

  </body>
</html>
</div>

<div id="Track" class="tabcontent">
  <!DOCTYPE html>
<html lang="en">
  <body style="color: white; background-color: #333333;">
    <br><br/>
    <section>
<center>
      <div class="container" style="padding-bottom:10px;">
        <div class="row">
          <div class="col-lg-12">

<h2 style="color:#35FFFF; text-align: center; padding-bottom: 2px;">
Track
</h2>

            <div style="border:0px solid #35FFFF; padding-top: 0px;">


<div style="border:1px solid #35FFFF; padding-top: 50px;">
<p style="color: white; background: ;">
Enter Track 1- URL</p>

  <input class="input_url_style" type="url" name="VideoTrack1" value="" placeholder="https://my-captions-track1.vtt">
<br/><br/>


kind
    <select name="kind1">
    <option value="" selected>Off</option>
    <option value="captions">captions</option>
    <option value="subtitles">subtitles</option>
    </select>
 

srclang
    <select name="srclang1">
    <option value="">Select</option>
    <option value="en" selected>en</option>
    <option value="hi">hi</option>
    <option value="fr">fr</option>
    </select>
 <br/><br/>

label
    <select name="label1">
    <option value="">Select</option>
    <option value="English" selected>English</option>
    <option value="Hindi">Hindi</option>
    <option value="Français">Français</option>
    </select>

default
 <select name="default1" style="padding-right:20px;">
 <option value="" selected>No</option>
 <option value="default">Yes</option>
 </select>
 <br/><br/>
</div>
<br/>

<div style="border:1px solid #35FFFF; padding-top: 50px;">
<p style="color: white; background: ;">
Enter Track 2- URL</p>
  <input class="input_url_style" type="url" name="VideoTrack2" value="" placeholder="https://my-captions-track2.vtt">
<br/><br/>
kind
    <select name="kind2" style="padding-right:0px;">
    <option value="" selected>Off</option>
    <option value="captions">captions</option>
    <option value="subtitles">subtitles</option>
    </select>
 

srclang
    <select name="srclang2">
    <option value="">Select</option>
    <option value="en">en</option>
    <option value="hi">hi</option>
    <option value="fr">fr</option>
    </select>
 <br/><br/>

label
    <select name="label2">
    <option value="">Select</option>
    <option value="English">English</option>
    <option value="Hindi">Hindi</option>
    <option value="Français">Français</option>
    </select>

default
 <select name="default2" style="padding-right:20px;">
 <option value="" selected>No</option>
 <option value="default">Yes</option>
 </select>
 <br/><br/>

</div>
<br/>
 <input onclick="openPage('Play', this, '#FF3333')" class="btn btn-success" style="padding: 3px; padding-left: 20px; padding-right: 20px; text-align: center; cursor: pointer;" type="button" value="Next"/>
<br/><br/><br/>

            </div>


          </div>
        </div>
   </div>
</center>

    </section>

  </body>
</html>
</div>

<div id="Play" class="tabcontent">
<br/>
<p style="color:#35FFFF; text-align: center; padding-bottom: 0px;">
Play
</p>


<div style="border:1px solid #35FFFF; padding-top: 35px;">
<center>
<button name="submit" type="submit" value="Play Video" onclick="javascript:location.href='video-url-plyr.php' type="button" style="padding:0px; border: 1px solid #35FFFF;">
    <img border="0" src="Images/player-logo.png" alt="Play Video Now" width="70%" height="70%">
</button>
<br/><br/>

 <input onclick="javascript: form.action='video-url-plyr.php';" class="btn btn-success" style="padding: 5px; text-align: center; cursor: pointer;" name="submit" type="submit" value="Play Video"/>
<br/>
<p style="color:#35FFFF;">or</p>

 <button class="btn btn-success" style="padding: 5px; text-align: center; cursor: pointer;" formaction="Embed-Code/index.php" formmethod="GET" name="embed" type="submit" value="Embed Code">Get Embed Code</button>
</form>
<br/><br/><br/>
</center>
</div>
<br/><br/>

</div>

<script>
 function openPage(pageName,elmnt,color) {
 var i, tabcontent, tablinks;
 tabcontent = document.getElementsByClassName("tabcontent");
 for (i = 0; i < tabcontent.length; i++) {
 tabcontent[i].style.display = "none";
 }
 tablinks = document.getElementsByClassName("tablink");
 for (i = 0; i < tablinks.length; i++) {
 tablinks[i].style.backgroundColor = "";
 }
 document.getElementById(pageName).style.display = "block";
 elmnt.style.backgroundColor = color;
 }
 
 // Get the element with id="defaultOpen" and click on it
 document.getElementById("defaultOpen").click();
 </script>
</body>
</html>