<?php 
$VideoSrc1 = $_GET['VideoSrc1'];
$VideoType1 = $_GET['VideoType1'];
$VideoQuality1 = $_GET['VideoQuality1'];

$VideoSrc2 = $_GET['VideoSrc2'];
$VideoType2 = $_GET['VideoType2'];
$VideoQuality2 = $_GET['VideoQuality2'];

$VideoSrc3 = $_GET['VideoSrc3'];
$VideoType3 = $_GET['VideoType3'];
$VideoQuality3 = $_GET['VideoQuality3'];

$VideoSrc4 = $_GET['VideoSrc4'];
$VideoType4 = $_GET['VideoType4'];
$VideoQuality4 = $_GET['VideoQuality4'];

$VideoPoster = $_GET['VideoPoster'];

$kind1 = $_GET['kind1'];
$label1 = $_GET['label1'];
$srclang1 = $_GET['srclang1'];
$VideoTrack1 = $_GET['VideoTrack1'];
$default1 = $_GET['default1'];

$kind2 = $_GET['kind2'];
$label2 = $_GET['label2'];
$srclang2 = $_GET['srclang2'];
$VideoTrack2 = $_GET['VideoTrack2'];
$default2 = $_GET['default2'];


// echo '<video controls height="100%"width="100%" autoplay="" preload="auto" src="'. $VideoSrc. '"></video>';
?>