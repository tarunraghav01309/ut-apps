<?php
//Custom videoURL Location
// $videoURL = 'https://ut-apps.000webhostapp.com/Video-URL_Plyr+/video-url-plyr.php';

//Get Domain URL
 $videoURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; 

//Define Video Plyr Directory or Location
$videoPlyr = "/Index_Resources/indexer/Video-URL%20Plyr+/video-url-plyr.php";


$VideoSrc1 = $_GET['VideoSrc1'];
$VideoSrc1 = urlencode("$VideoSrc1");

$VideoType1 = $_GET['VideoType1'];
$VideoType1 = urlencode("$VideoType1");

$VideoQuality1 = $_GET['VideoQuality1'];
$VideoQuality1 = urlencode("$VideoQuality1");


$VideoSrc2 = $_GET['VideoSrc2'];
$VideoSrc2 = urlencode("$VideoSrc2");

$VideoType2 = $_GET['VideoType2'];
$VideoType2 = urlencode("$VideoType2");

$VideoQuality2 = $_GET['VideoQuality2'];
$VideoQuality2 = urlencode("$VideoQuality2");


$VideoSrc3 = $_GET['VideoSrc3'];
$VideoSrc3 = urlencode("$VideoSrc3");

$VideoType3 = $_GET['VideoType3'];
$VideoType3 = urlencode("$VideoType3");

$VideoQuality3 = $_GET['VideoQuality3'];
$VideoQuality3 = urlencode("$VideoQuality3");


$VideoSrc4 = $_GET['VideoSrc4'];
$VideoSrc4 = urlencode("$VideoSrc4");

$VideoType4 = $_GET['VideoType4'];
$VideoType4 = urlencode("$VideoType4");

$VideoQuality4 = $_GET['VideoQuality4'];
$VideoQuality4 = urlencode("$VideoQuality4");


$VideoPoster = $_GET['VideoPoster'];
$VideoPoster = urlencode("$VideoPoster");


$kind1 = $_GET['kind1'];
$kind1 = urlencode("$kind1");

$label1 = $_GET['label1'];
$label1 = urlencode("$label1");

$srclang1 = $_GET['srclang1'];
$srclang1 = urlencode("$srclang1");

$VideoTrack1 = $_GET['VideoTrack1'];
$VideoTrack1 = urlencode("$VideoTrack1");

$default1 = $_GET['default1'];
$default1 = urlencode("$default1");


$kind2 = $_GET['kind2'];
$kind2 = urlencode("$kind2");

$label2 = $_GET['label2'];
$label2 = urlencode("$kind2");

$srclang2 = $_GET['srclang2'];
$srclang2 = urlencode("$srclang2");

$VideoTrack2 = $_GET['VideoTrack2'];
$VideoTrack2 = urlencode("$VideoTrack2");

$default2 = $_GET['default2'];
$default2 = urlencode("$default2");


 $convertedURL = "$videoURL$videoPlyr?VideoSrc1=$VideoSrc1&VideoType1=$VideoType1&VideoQuality1=$VideoQuality1&VideoSrc2=$VideoSrc2&VideoType2=$VideoType2&VideoQuality2=$VideoQuality2&VideoSrc3=$VideoSrc3&VideoType3=$VideoType3&VideoQuality3=$VideoQuality3&VideoSrc4=$VideoSrc4&VideoType4=$VideoType4&VideoQuality4=$VideoQuality4&VideoPoster=$VideoPoster&kind1=$kind1&label1=$label1&srclang1=$srclang1&VideoTrack1=$VideoTrack1&default1=$default1&kind2=$kind2&label2=$label2&srclang2=$srclang2&VideoTrack2=$VideoTrack2&default2=$default2&submit=Play+Video";

?>

