<?php
//Configuration
// Please Specify  'URL' , 'Title' and 'CountdownTime' below for Redirect to another page !

// URL
$redirectURL = "https://drive.google.com/drive/u/0/mobile/folders/1nKReVyMmciIaS0mitMcP40BAYkk_5Rjq";

// Title
$Title = "Drive Music Videos";

// CountdownTime (in seconds)
$CountdownTime = "1";

?>

<!--
// URL Usage Example!
<?php echo("$redirectURL"); ?>

// TITLE Usage Example!
<?php echo("$Title"); ?>

// CountdownTime - Usage!
<?php echo("$CountdownTime"); ?>
-->

<!Doctype html>
<html>
<title><?php echo("$Title"); ?></title>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="<?php echo("$CountdownTime"); ?>; url=<?php echo("$redirectURL"); ?>" />
<script type="text/javascript">
// For Fast Auto Redirect
  // window.location.href = "<?php echo("$redirectURL"); ?>";
</script>
</head>

<body>
<!-- Note: don't tell people to `click` the link, just tell them that it is a link. -->
<center>
<h3>Redirecting to = <?php echo("$Title"); ?></h3>
<p>If you are not redirected automatically, follow a Link given below -</p>

<a onclick="window.location.href = '<?php echo("$redirectURL"); ?>' ;" href="#">Link</a>

</center>
</body>
</html>