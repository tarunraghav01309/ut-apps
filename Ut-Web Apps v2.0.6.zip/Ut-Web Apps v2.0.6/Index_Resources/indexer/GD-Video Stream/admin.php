<!Doctype Html>
<html>
	<head>
		<title>File Share</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<style type="text/css">
		body {
                                padding-top:5%;
                                padding-bottom:50%;
			}
			.btn{
				padding: 13px;
				color: #fff;
				background-color: #000;
				width: 140px;
				border: none;
				cursor: pointer;
                                font-size:15px;
			}
		</style>
	</head>
	<body>
		<center>
			<h1>Admin Panel</h1>
                        <h5>for manage</h5>
			<h4 style="color:red;">GD-Video Stream</h4>
			<a href="stream-videos.php" ><input class="btn" type="button" value="Stream Videos" /></a><br/><br/>

<a href="index.php" ><input class="btn" type="button" value="Add" /></a>

			<a href="delete-stream-ids.php" ><input class="btn" type="button" value="Delete" /></a>
		</center>
	</body>
</html>
