<?php
error_reporting(0);
$url = $_GET["url"];
$name = $_GET["filename"];
?>
</div>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <title>URL to File Downloader v2</title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    <script type="text/javascript">
$(document).ready(function(){
   $('#myForm').submit(function() {
    $('#loaderImg').show(); 
   return true;
    });
});
  </script>

<!-- for Hide & Show title P (v2 text) element -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
 $(".showdiv").click(function(){
   $("#hidden").toggle();
 });
});
</script>
</head>
<body>
    
    <div class="container bg-white wrapper shadow p-4" style="width: 100%;">
<center>
        <h2 class="showdiv" class="title text-center mb-4" style="margin-bottom:10px">URL to File Downloader</h2>

<p id="hidden" class="title text-center mb-4" style="margin-top:0px">v2</p>
</center>

        <form action="download.php" method="get" class="form" id="myForm" >
            <div class="mb-3">
                <label for="url" class="form-label">URL</label>
                <input type="url" name="url" id="url" class="form-control" value="<?php echo("$url"); ?>" placeholder="Enter File URL to download" required>

<label for="url" class="form-label">Rename</label>
                <input type="text" name="newname" id="url" class="form-control" value="<?php echo("$name"); ?>" placeholder="Enter new name (optional)">
            </div>

            <button onclick="myFunction()" type="submit" name="submit" class="btn btn-primary w-100 shadow-sm">Download</button>
<br>
<center>
<img src="images/loading.svg" alt="loading..." style="display:none; height:100px; width:auto;" id="loaderImg">
<p id="demo"></p>
</center>

        </form>
    </div>

    <!-- Bootstrap Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
<script>
function myFunction() {
// let text = "Do you really want to download this file?";

var agree=confirm("Do you really want to download this file?");

 //if (confirm(text) == true) {
   if (agree){

alert("Downloading...");
text = "Downloading started...";
  }else {
   alert("Cancelled");
text = "Downloading cancelled!, Please try again.";
   document.getElementById("demo").innerHTML = text;
//reset form values
document.getElementById("myForm").reset();
 }

 document.getElementById("demo").innerHTML = text;
this.form.submit();
}
</script>
</body>
</html>