<?php
error_reporting(0);

// define file name and url
$file = $_GET["url"];
$filename = $_GET["newname"];

if($filename){
    $filename = $_GET["newname"];

}else{
    
$filename = basename($file);
}

$userCanDownloadThisFile = true; // apply your logic here
 
if (isset($_GET["submit"]) && $userCanDownloadThisFile) {

header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Transfer-Encoding: file");
        readfile($file);
exit();
}else{
echo("Sorry, Download Blocked by ut-apps Admin. or userCanDownloadThisFile is = false");
}

?>