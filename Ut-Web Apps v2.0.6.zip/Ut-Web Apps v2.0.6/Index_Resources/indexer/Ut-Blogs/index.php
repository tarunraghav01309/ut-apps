<?php
//Configuration 
include("include/config.php");
?>

<!--
// URL Usage Example!
<?php echo("$redirectURL"); ?>

// TITLE Usage Example!
<?php echo("$Title"); ?>

// CountdownTime - Usage!
<?php echo("$CountdownTime"); ?>
-->

<!Doctype html>
<html>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Redirecting to = <?php echo("$Title"); ?></title>
<head>
<link rel="stylesheet" href="include/styles.css">
<?php
// fast redirects to web page without redirection notice if - (true)
// slow redirects to web page and shows a redirection notice if - (false)

if($Fast_Redirect === true)
{
    //used if true
?>

<script type="text/javascript">
// For Fast Auto Redirect
   window.location.href = "<?php echo("$redirectURL"); ?>";
</script>
<?php
}
?>

<?php
if($Fast_Redirect === false){
    //used if false
   include"include/script.js";
}
?>

</head>

<div id="master-wrap">
 <div id="logo-box">

   <div class="animated fast fadeInUp">
     <!-- <div class="icon"></div> -->
<br>
<center>
<div id="countdown" class="circle"></div>
</center>
<br/>
     <h1>Please Wait...</h1>
   </div>

   <div class="notice animated fadeInUp">
     <p class="lead">Redirecting to = <?php echo("$Title"); ?></p>
<p>If you are not redirected automatically, please follow Link given below -</p>
     <a onclick="sample();" id= "gameStart" class="btn animation" href="#">&larr; Follow Link</a>
   </div>

   <div class="footer animated slow fadeInUp">
     <p class="copyright">© <script>document.write(new Date().getFullYear())</script> Tarun Raghav •</p>
   </div>

 </div>
 <!-- /#logo-box -->
</div>
<!-- /#master-wrap -->