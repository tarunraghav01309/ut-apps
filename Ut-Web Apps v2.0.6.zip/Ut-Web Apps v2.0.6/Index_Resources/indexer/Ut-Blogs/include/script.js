<script>
// Auto Click Button on page load -
   window.onload=function(){
   document.getElementById("gameStart").click();
    }

// Countdown Timer
 var timeleft = <?php echo("$CountdownTime"); ?>;
 function sample() {
 var downloadTimer = setInterval(function 
 function1(){ 
 document.getElementById("countdown").innerHTML = timeleft + "&nbsp"+"<!-- seconds remaining -->";
 
 timeleft -= 1;
 if(timeleft <= 0){
 clearInterval(downloadTimer);
 
 document.getElementById("countdown").innerHTML = "<style>.circle {width:150px; font-size:20px; border:none; border-radius:0px;; color:green; color:white;}</style>Loading...";
 window.location = '<?php echo("$redirectURL"); ?>';
}
}, 1000);

console.log(countdown)
}
</script>