<?php
//Configuration
// Please Specify  'redirectURL' , 'Title' , 'CountdownTime' and 'Fast_Redirect' below for Redirect to another page !

// Define URL to Redirect
$redirectURL = "https://ut-blogs.000webhostapp.com/";

// Website Title
$Title = "Ut-Blogs";

// CountdownTime (in seconds)
$CountdownTime = "5";

// Please define Fast_Redirect - (true/false)
$Fast_Redirect = false;

?>