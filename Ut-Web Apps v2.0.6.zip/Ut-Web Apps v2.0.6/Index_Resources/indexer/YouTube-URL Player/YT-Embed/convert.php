<?php 
 $videoURL = $_GET['url'];
  $convertedURL = str_replace("watch?v=","embed/", $videoURL);
?>