<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>YouTube-URL Player</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
  </head>

  <body style="color: white; background-color: skyblue;">
    <br><br>
<center>
    <section  style="background-color: black; border: 2px solid white; border-radius: 10px;" class="col-lg-12">
      <div class="container">
        <div class="row">
          
          <div>
           <br>
<h2 style="text-align: center; color: #FF1111; background: silver; border: 2px solid #35FFFF; border-radius: 10px; width: 95%; height: 50px">
YouTube-URL Player</h2>
            <br>

<h6 style="text-align: center; color: skyblue;">Play YouTube videos by just entering YouTube URL below</h6>

<h7 style="color: #FF3333;">
Example url: -</h7>
       
<p style="color: red; background: skyblue; border: ; border-radius: 4px; width: 80%;">
https://www.youtube.com/watch?v=pTA7Rl3SLGw
</p>
<br/>

<div id= "ExampleURL"></div>
            <form>
              <div class="form-group">
                <input name="url" type="url" id="Value" class="form-control url" placeholder="Paste YouTube Video URL Here" list="browsers" required/>
 <datalist id="browsers">
    <option value="https://www.youtube.com/watch?v=w0EF3AxJwLU">
<option value="https://www.youtube.com/watch?v=6US7RN74D0k">
    <option value="https://www.youtube.com/watch?v=pTA7Rl3SLGw">
  </datalist>
              </div>
              <div class="form-group">
                <button name="submit" type="submit" class="btn btn-success" onClick="myFunction()">Play Video</button>

<button class="btn btn-success" onclick="document.getElementById('Value').value = ''">Reset</button>


<button class="btn btn-success" onclick="javascript:location.href='YT-Embed'">Embed</button>


<button  class="btn btn-success" 
onclick="change(value)">Example</button>
              </div>
            </form>

          </div>

          <div class="col-lg-12">
            
            <div class="embed-responsive embed-responsive-16by9">

              <iframe style="border: 1px solid #35FFFF;" class="embed-responsive-item" src="" frameborder="" allow="accelerometer; autoplay; clipboard-write; encrypted-media; download; gyroscope; picture-in-picture" allowfullscreen width="100%"></iframe>
<p id="textshow" style="color: black; background: skyblue; text-align: center; border: 2px solid red; border-radius: 10px;"></p>

<p style="color: #FF6666;">Error: - 
No Videos searched yet, Please Enter a YouTube Video URL Above!</p>
            </div>

          </div>
        </div>
      </div>    
<br>
    </section>
</center>
<br>
  <a style="background-color: #364655;
  color: #35FFFF; border-radius: 5px;" href="../About-us_Page.html">© Design by Tarun Raghav <script>document.write(new Date().getFullYear())</script></a>
  <span>• </span>    
<br></br>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="javascript/custom.js" defer></script>
<script>
      function myFunction() {
        document.getElementById("textshow").innerHTML = "Loading...";
      }
  </script>
<script>
         function change(value){
         document.getElementById("Value").value= "https://www.youtube.com/watch?v=2A8Chs68Pfw";
         document.getElementById("ExampleURL").innerHTML= "Usage:- https://www.youtube.com/watch?v={Video ID}";
         }
   </script>
  </body>
</html>
