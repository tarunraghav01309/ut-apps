<?php include("Index_Resources/includes/GetDomainURL.php");
$GetDomainURL = "$GetDomainURL";
$WebsiteURL = "$GetDomainURL";
 ?>

<?php
$units = explode(' ', 'B KB MB GB TB PB');

//Define Total Disk Space Below in mebibytes or gibibytes
$SIZE_LIMIT = 314572800; // 300MB
$disk_used = foldersize("./");

$disk_remaining = $SIZE_LIMIT - $disk_used;

//echo("<html><body>");
$DiskSpaceUsed = ('' . format_size($disk_used) . '');
$DiskSpaceLeft = ('' . format_size($disk_remaining) . '');
// echo("</body></html>");


function foldersize($path) {
$total_size = 0;
$files = scandir($path);
$cleanPath = rtrim($path, '/'). '/';

foreach($files as $t) {
if ($t<>"." && $t<>"..") {
$currentFile = $cleanPath . $t;
if (is_dir($currentFile)) {
$size = foldersize($currentFile);
$total_size += $size;
}
else {
$size = filesize($currentFile);
$total_size += $size;
}
}   
}

return $total_size;
}


function format_size($size) {
global $units;

$mod = 1024;

for ($i = 0; $size > $mod; $i++) {
$size /= $mod;
}

$endIndex = strpos($size, ".")+3;

return substr( $size, 0, $endIndex).' '.$units[$i];
}

?>

<?php
# Size in Bytes
$size = $SIZE_LIMIT;
# Call this function to convert bytes to KB/MB/GB/TB
$TotalSize = convertToReadableSize($size);
# Output => 14.2 MB

function convertToReadableSize($size){
  $base = log($size) / log(1024);
  $suffix = array("", "KB", "MB", "GB", "TB");
  $f_base = floor($base);
  return round(pow(1024, $base - floor($base)), 1) . $suffix[$f_base];
}
?>

<!Doctype html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
body {
width: 100vw;
min-height: 100vh;
background-color: var(--bs-dark);
display: flex;
justify-content: center;
overflow-x:hidden;
}

@keyframes startBar {
0% {
width: 0;
}
100% {
width: 100%;
}
}

.bar {
animation-name: startBar;
animation-duration: 3.0s !important;
animation-fill-mode: forwards;
animation-timing-function: linear;
}

.usage-item {
border-color: rgba($color: #fff, $alpha: .1) !important;
}
</style>
</head>

<body>
<div class="usage d-flex flex-column col-11 col-md-9 col-lg-8 col-xl-7 mt-5 text-white">
<div class="header d-flex flex-column">
<div class="d-flex justify-content-between align-items-center mb-1">
<h4>Storage</h4>
<span class="text-muted" style="font-size: 1rem;">Total : <span id="total-value">32</span>MB</span>
</div>
<div class="progress bg-transparent" style="height: 200px;">

<!-- Diskspace Used - Progress -->
<div class="progress-bar bg-transparent" style="width: <?php
echo(round($DiskSpaceUsed) . "");
?>%;">
<div class="progress-bar bg-warning bg-gradient bar h-100"></div>
</div>

<!-- Diskspace Left - Progress -->
<div class="progress-bar bg-transparent" style="width: <?php
echo(round($DiskSpaceLeft) . "");
?>%;">
<div class="progress-bar bg-primary bg-gradient bar h-100"></div>
</div>


</div>
</div>

<!-- Diskspace Used -->
<div class="body d-flex flex-column">
<div class="usage-item d-flex align-items-center justify-content-between mt-3 border-bottom border-secondary pb-2">
<div class="d-flex align-items-center">
<div class="usage-icon bg-warning rounded" style="width: 25px;height: 25px;"></div>
<span class="usage-title fs-5 ms-2">Diskspace Used</span>
</div>
<span class="text-muted">
<span id="system-value">5</span>MB
</span>
</div>

<!-- Diskspace Left -->
<div class="usage-item d-flex align-items-center justify-content-between mt-3 border-bottom border-secondary pb-2">
<div class="d-flex align-items-center">
<div class="usage-icon bg-primary rounded" style="width: 25px;height: 25px;"></div>
<span class="usage-title fs-5 ms-2">Diskspace Left</span>
</div>
<span class="text-muted">
<span id="files-value">5</span>MB
</span>
</div>


</div>
</div>

<script>
const usageValues = {
total: document.querySelector("#total-value"),
system: document.querySelector("#system-value"),
files: document.querySelector("#files-value"),
images: document.querySelector("#images-value"),
videos: document.querySelector("#videos-value"),
audios: document.querySelector("#audios-value")
}

function counter(value, element) {
let val = 0;
let counterInterval = setInterval(() => {
if (val == value) {
element.innerText = val;
clearTimeout(counterInterval);
} else {
val++;
element.innerText = val;
}
},
 // Define Animation Duration in seconds-
 7);
}

counter(
<?php
echo(round($TotalSize) . "");
?>, usageValues.total);
counter(<?php
echo(round($DiskSpaceUsed) . "");
?>, usageValues.system);
counter(<?php
echo(round($DiskSpaceLeft) . "");
?>, usageValues.files);

</script>
</body>
</html>