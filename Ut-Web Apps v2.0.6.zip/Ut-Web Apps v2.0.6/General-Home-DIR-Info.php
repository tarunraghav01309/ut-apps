<?php include("Index_Resources/includes/GetDomainURL.php");

$GetDomainURL = "$GetDomainURL";
$WebsiteURL = "$GetDomainURL";

 ?>

<?php

//Define Web Apps Folder LOCATION to count Apps 
$AppsDir = "Index_Resources/indexer/";
$appsCount = 0;
$dh = opendir($AppsDir);
while (($file = readdir($dh)) !== false) {
    if ($file != "." && $file != ".." && is_dir($AppsDir . DIRECTORY_SEPARATOR . $file)) {
        $appsCount++;
    }
}
closedir($dh);

?>

<?php 
//FOLDER LOCATION TO COUNT FILES -
$directory = "./";
$filesCount = 0;
$files = 
//FILE TYPES TO COUNT FILES -
glob($directory . "*.{html,css,php,xml}",GLOB_BRACE);

if ($files){
 $filesCount = count($files);
}

$subDirectory = 0;
$dh = opendir($directory);
while (($file = readdir($dh)) !== false) {
    if ($file != "." && $file != ".." && is_dir($directory . DIRECTORY_SEPARATOR . $file)) {
        $subDirectory++;
    }
}
closedir($dh);


$filecount= $filesCount;
$dh = opendir($directory);
while (($file = readdir($dh)) !== false) {
    if ($file != "." && $file != ".." && is_dir($directory . DIRECTORY_SEPARATOR . $file)) {
        $filecount++;
    }
}
closedir($dh);
?>



<?php
// Total Count All Values in array
$a = array
(
// Files
$filesCount,
// Folders
$subDirectory,
// Apps
 $appsCount
);
$TotalValue ="" . array_sum($a) . "\n";
?>

<!--
Total Value = <?php echo("$TotalValue"); ?>
-->

<!--
Website URL = <?php echo("$WebsiteURL"); ?>/
<br/>

Home Dir = <?php echo("$directory"); ?>
<br/>

Files = <?php echo("$filesCount"); ?>
<br/>

Folders = <?php echo("$subDirectory"); ?>
<br/>

Total = <?php echo("$filecount"); ?>
<br/><br/>

Apps Dir = <?php echo("$AppsDir"); ?>
<br/>

Apps = <?php echo("$appsCount"); ?>
<br/>
-->

<!Doctype html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
body {
width: 100vw;
min-height: 100vh;
background-color: var(--bs-dark);
display: flex;
justify-content: center;
overflow-x:hidden;
}

@keyframes startBar {
0% {
width: 0;
}
100% {
width: 100%;
}
}

.bar {
animation-name: startBar;
animation-duration: 3.0s !important;
animation-fill-mode: forwards;
animation-timing-function: linear;
}

.usage-item {
border-color: rgba($color: #fff, $alpha: .1) !important;
}
</style>
</head>

<body>
<div class="usage d-flex flex-column col-11 col-md-9 col-lg-8 col-xl-7 mt-5 text-white">
<div class="header d-flex flex-column">
<div class="d-flex justify-content-between align-items-center mb-1">
<h4>General Home DIR Info.</h4>
<span class="text-muted" style="font-size: 1rem;">Total : <span id="total-value">32</span></span>
</div>
<div class="progress bg-transparent" style="height: 200px;">

<!-- Files Count - Progress -->
<div class="progress-bar bg-transparent" style="width: <?php
echo(round($filecount) . "");
?>%;">
<div class="progress-bar bg-warning bg-gradient bar h-100"></div>
</div>

<!-- Folders Count - Progress -->
<div class="progress-bar bg-transparent" style="width: <?php
echo(round($filesCount) . "");
?>%;">
<div class="progress-bar bg-primary bg-gradient bar h-100"></div>
</div>

<!-- Apps Count - Progress -->
<div class="progress-bar bg-transparent" style="width: <?php echo("$appsCount"); ?>%;">
<div class="progress-bar bg-success bg-gradient bar h-100"></div>
</div>


</div>
</div>

<!-- Files Count -->
<div class="body d-flex flex-column">
<div class="usage-item d-flex align-items-center justify-content-between mt-3 border-bottom border-secondary pb-2">
<div class="d-flex align-items-center">
<div class="usage-icon bg-warning rounded" style="width: 25px;height: 25px;"></div>
<span class="usage-title fs-5 ms-2">Files</span>
</div>
<span class="text-muted">
<span id="system-value">5</span>
</span>
</div>

<!-- Folders Count -->
<div class="usage-item d-flex align-items-center justify-content-between mt-3 border-bottom border-secondary pb-2">
<div class="d-flex align-items-center">
<div class="usage-icon bg-primary rounded" style="width: 25px;height: 25px;"></div>
<span class="usage-title fs-5 ms-2">Folders</span>
</div>
<span class="text-muted">
<span id="files-value">5</span>
</span>
</div>

<!-- Apps Count -->
<div class="usage-item d-flex align-items-center justify-content-between mt-3 border-bottom border-secondary pb-2">
<div class="d-flex align-items-center">
<div class="usage-icon bg-success rounded" style="width: 25px;height: 25px;"></div>
<span class="usage-title fs-5 ms-2">Apps</span>
</div>
<span class="text-muted">
<span id="apps-value">5</span>
</span>
</div>


</div>
</div>

<script>
const usageValues = {
total: document.querySelector("#total-value"),
system: document.querySelector("#system-value"),
files: document.querySelector("#files-value"),
apps: document.querySelector("#apps-value"),
videos: document.querySelector("#videos-value"),
audios: document.querySelector("#audios-value")
}

function counter(value, element) {
let val = 0;
let counterInterval = setInterval(() => {
if (val == value) {
element.innerText = val;
clearTimeout(counterInterval);
} else {
val++;
element.innerText = val;
}
},
 // Define Animation Duration in seconds-
 140);
}

counter(
<?php
echo(round($TotalValue) . "");
?>, usageValues.total);
counter(<?php
echo(round($filesCount) . "");
?>, usageValues.system);
counter(<?php
echo(round($subDirectory) . "");
?>, usageValues.files);
counter(<?php echo("$appsCount"); ?>, usageValues.apps);
</script>
</body>
</html>